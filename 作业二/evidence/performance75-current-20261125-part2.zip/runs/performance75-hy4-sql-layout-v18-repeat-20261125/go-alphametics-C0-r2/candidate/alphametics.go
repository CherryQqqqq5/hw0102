package alphametics

import (
	"errors"
	"math"
	"sort"
	"strings"
)

var errNoSolution = errors.New("no solution")

// Solve finds a digit assignment satisfying an alphametic addition puzzle.
func Solve(puzzle string) (map[string]int, error) {
	addends, result, err := parsePuzzle(puzzle)
	if err != nil {
		return nil, err
	}

	letters, coefficients, leading, err := buildConstraints(addends, result)
	if err != nil {
		return nil, err
	}

	solution := search(letters, coefficients, leading)
	if solution == nil {
		return nil, errNoSolution
	}
	return solution, nil
}

func parsePuzzle(puzzle string) ([]string, string, error) {
	if strings.Count(puzzle, "==") != 1 {
		return nil, "", errNoSolution
	}

	parts := strings.Split(puzzle, "==")
	left := strings.Split(parts[0], "+")
	right := strings.Split(parts[1], "+")
	if len(right) != 1 {
		return nil, "", errNoSolution
	}

	addends := make([]string, 0, len(left))
	for _, word := range append(left, right[0]) {
		word = strings.TrimSpace(word)
		if word == "" || !isWord(word) {
			return nil, "", errNoSolution
		}
		addends = append(addends, word)
	}
	return addends[:len(addends)-1], addends[len(addends)-1], nil
}

func isWord(word string) bool {
	for i := 0; i < len(word); i++ {
		c := word[i]
		if !((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
			return false
		}
	}
	return true
}

func buildConstraints(addends []string, result string) ([]byte, []int64, []bool, error) {
	index := make(map[byte]int)
	letters := make([]byte, 0)
	coefficients := make([]int64, 0)
	leading := make([]bool, 0)

	include := func(c byte) int {
		if i, ok := index[c]; ok {
			return i
		}
		i := len(letters)
		index[c] = i
		letters = append(letters, c)
		coefficients = append(coefficients, 0)
		leading = append(leading, false)
		return i
	}

	addWord := func(word string, sign int64) error {
		if len(word) > 1 {
			leading[include(word[0])] = true
		}
		place := int64(1)
		for i := len(word) - 1; i >= 0; i-- {
			if place > math.MaxInt64/10 {
				return errNoSolution
			}
			idx := include(word[i])
			delta := sign * place
			if sign > 0 && coefficients[idx] > math.MaxInt64-delta {
				return errNoSolution
			}
			if sign < 0 && coefficients[idx] < math.MinInt64-delta {
				return errNoSolution
			}
			coefficients[idx] += delta
			if i > 0 {
				place *= 10
			}
		}
		return nil
	}

	for _, word := range addends {
		if err := addWord(word, 1); err != nil {
			return nil, nil, nil, err
		}
	}
	if err := addWord(result, -1); err != nil {
		return nil, nil, nil, err
	}
	if len(letters) > 10 {
		return nil, nil, nil, errNoSolution
	}
	return letters, coefficients, leading, nil
}

func search(letters []byte, coefficients []int64, leading []bool) map[string]int {
	n := len(letters)

	// Assign larger coefficients first so the remaining-range bound prunes early.
	order := make([]int, n)
	for i := range order {
		order[i] = i
	}
	sort.Slice(order, func(i, j int) bool {
		a, b := order[i], order[j]
		if abs64(coefficients[a]) != abs64(coefficients[b]) {
			return abs64(coefficients[a]) > abs64(coefficients[b])
		}
		return a < b
	})

	positive := make([]int, 0, n)
	negative := make([]int, 0, n)
	for i, c := range coefficients {
		switch {
		case c > 0:
			positive = append(positive, i)
		case c < 0:
			negative = append(negative, i)
		}
	}
	sort.Slice(positive, func(i, j int) bool { return coefficients[positive[i]] > coefficients[positive[j]] })
	sort.Slice(negative, func(i, j int) bool { return coefficients[negative[i]] < coefficients[negative[j]] })

	assigned := make([]int, n)
	for i := range assigned {
		assigned[i] = -1
	}
	usedDigit := [10]bool{}

	var dfs func(depth int, total int64) map[string]int
	dfs = func(depth int, total int64) map[string]int {
		if depth == n {
			if total != 0 {
				return nil
			}
			result := make(map[string]int, n)
			for i, letter := range letters {
				result[string(letter)] = assigned[i]
			}
			return result
		}

		// Rearrangement inequality gives the least and greatest total still
		// obtainable from the unassigned letters and available digits.
		if !totalReachable(total, coefficients, positive, negative, assigned, &usedDigit) {
			return nil
		}

		idx := order[depth]
		for digit := 0; digit < 10; digit++ {
			if usedDigit[digit] || (leading[idx] && digit == 0) {
				continue
			}
			usedDigit[digit] = true
			assigned[idx] = digit
			if result := dfs(depth+1, total+coefficients[idx]*int64(digit)); result != nil {
				return result
			}
			assigned[idx] = -1
			usedDigit[digit] = false
		}
		return nil
	}

	return dfs(0, 0)
}

func totalReachable(total int64, coefficients []int64, positive, negative []int, assigned []int, usedDigit *[10]bool) bool {
	digits := make([]int64, 0, 10)
	for d := 0; d < 10; d++ {
		if !usedDigit[d] {
			digits = append(digits, int64(d))
		}
	}

	pos := make([]int64, 0, len(positive))
	for _, idx := range positive {
		if assigned[idx] < 0 {
			pos = append(pos, coefficients[idx])
		}
	}
	neg := make([]int64, 0, len(negative))
	for _, idx := range negative {
		if assigned[idx] < 0 {
			neg = append(neg, coefficients[idx])
		}
	}

	min := int64(0)
	max := int64(0)
	for i, c := range pos {
		min += c * digits[i]
		max += c * digits[len(digits)-1-i]
	}
	for i, c := range neg {
		// Negative coefficients are ordered from most negative to least.
		min += c * digits[len(digits)-1-i]
		max += c * digits[i]
	}
	return total+min <= 0 && total+max >= 0
}

func abs64(v int64) int64 {
	if v < 0 {
		if v == math.MinInt64 {
			return math.MaxInt64
		}
		return -v
	}
	return v
}
