package trinary

import "errors"

var (
	errInvalidTrinary = errors.New("invalid trinary")
	errTrinaryRange   = errors.New("trinary value out of range")
)

func ParseTrinary(arg string) (int64, error) {
	if len(arg) == 0 {
		return 0, errInvalidTrinary
	}

	const maxInt64 int64 = 1<<63 - 1

	var value int64
	for _, ch := range arg {
		if ch < '0' || ch > '2' {
			return 0, errInvalidTrinary
		}

		digit := int64(ch - '0')
		if value > (maxInt64-digit)/3 {
			return 0, errTrinaryRange
		}
		value = value*3 + digit
	}

	return value, nil
}
