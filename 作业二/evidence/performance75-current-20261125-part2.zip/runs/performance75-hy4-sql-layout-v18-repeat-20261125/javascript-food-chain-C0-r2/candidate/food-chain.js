const SPIDER_SUFFIX = 'that wriggled and jiggled and tickled inside her';

const CREATURES = [
  { name: 'fly' },
  {
    name: 'spider',
    remark: 'It wriggled and jiggled and tickled inside her.',
    suffix: SPIDER_SUFFIX,
  },
  { name: 'bird', remark: 'How absurd to swallow a bird!' },
  { name: 'cat', remark: 'Imagine that, to swallow a cat!' },
  { name: 'dog', remark: 'What a hog, to swallow a dog!' },
  { name: 'goat', remark: 'Just opened her throat and swallowed a goat!' },
  { name: 'cow', remark: "I don't know how she swallowed a cow!" },
  { name: 'horse', remark: "She's dead, of course!" },
];

const FLY_FATE = "I don't know why she swallowed the fly. Perhaps she'll die.";

export class Song {
  verse(verseNumber) {
    const index = Number(verseNumber) - 1;
    const creature = CREATURES[index];

    if (!creature) {
      return '';
    }

    const lines = [`I know an old lady who swallowed a ${creature.name}.`];

    if (creature.remark) {
      lines.push(creature.remark);
    }

    if (creature.name !== 'horse') {
      for (let current = index; current > 0; current -= 1) {
        const swallowed = CREATURES[current];
        const caught = CREATURES[current - 1];
        const suffix = caught.suffix ? ` ${caught.suffix}` : '';

        lines.push(
          `She swallowed the ${swallowed.name} to catch the ${caught.name}${suffix}.`
        );
      }

      lines.push(FLY_FATE);
    }

    return `${lines.join('\n')}\n`;
  }

  verses(firstVerse, lastVerse) {
    const verses = [];

    for (let number = firstVerse; number <= lastVerse; number += 1) {
      verses.push(this.verse(number));
    }

    return `${verses.join('\n')}\n`;
  }
}
