#include "parallel_letter_frequency.h"

#include <algorithm>
#include <array>
#include <cstddef>
#include <thread>
#include <utility>
#include <vector>

namespace parallel_letter_frequency {
namespace {

using Counts = std::array<unsigned long long, 26>;

void count_text(std::string_view text, Counts& counts) noexcept {
    for (const char character : text) {
        if (character >= 'a' && character <= 'z') {
            ++counts[static_cast<std::size_t>(character - 'a')];
        } else if (character >= 'A' && character <= 'Z') {
            ++counts[static_cast<std::size_t>(character - 'A')];
        }
    }
}

std::size_t worker_count(std::size_t total_characters) noexcept {
    if (total_characters == 0) {
        return 1;
    }

    const unsigned int available = std::thread::hardware_concurrency();
    std::size_t workers = available == 0 ? 1 : static_cast<std::size_t>(available);

    // Avoid creating more threads than there are characters to process, and
    // avoid the overhead of threads for very small inputs.
    constexpr std::size_t minimum_characters_per_worker = 4096;
    const std::size_t workers_by_size =
        total_characters / minimum_characters_per_worker +
        (total_characters % minimum_characters_per_worker != 0 ? 1 : 0);
    workers = std::min(workers, workers_by_size);
    return std::max<std::size_t>(1, workers);
}

// Returns the half-open global character range owned by one worker.
std::pair<std::size_t, std::size_t> range_for(std::size_t worker,
                                              std::size_t total_characters,
                                              std::size_t workers) noexcept {
    const std::size_t base = total_characters / workers;
    const std::size_t remainder = total_characters % workers;
    const std::size_t begin = worker * base + std::min(worker, remainder);
    const std::size_t end = begin + base + (worker < remainder ? 1 : 0);
    return {begin, end};
}

Counts count_range(const std::vector<std::string_view>& texts,
                   const std::vector<std::size_t>& offsets,
                   std::size_t begin,
                   std::size_t end) noexcept {
    Counts counts{};
    if (begin >= end) {
        return counts;
    }

    // offsets[i] is the global position of texts[i]. Searching from
    // offsets.begin() + 1 finds the first text whose end is after `begin`,
    // which also correctly skips runs of empty texts at a boundary.
    const auto first_end =
        std::upper_bound(offsets.begin() + 1, offsets.end(), begin);
    std::size_t index =
        static_cast<std::size_t>(first_end - offsets.begin()) - 1;

    for (; index < texts.size() && offsets[index] < end; ++index) {
        const std::size_t text_begin = std::max(begin, offsets[index]);
        const std::size_t text_end = std::min(end, offsets[index + 1]);
        if (text_begin < text_end) {
            count_text(texts[index].substr(text_begin - offsets[index],
                                          text_end - text_begin),
                       counts);
        }
    }
    return counts;
}

}  // namespace

std::map<char, int> frequency(const std::vector<std::string_view>& texts) {
    std::vector<std::size_t> offsets;
    offsets.reserve(texts.size() + 1);
    offsets.push_back(0);
    for (const std::string_view text : texts) {
        offsets.push_back(offsets.back() + text.size());
    }

    const std::size_t total_characters = offsets.back();
    const std::size_t workers = worker_count(total_characters);
    std::vector<Counts> partial_counts(workers);

    if (workers == 1) {
        partial_counts[0] = count_range(texts, offsets, 0, total_characters);
    } else {
        std::vector<std::thread> threads;
        threads.reserve(workers - 1);
        for (std::size_t worker = 1; worker < workers; ++worker) {
            threads.emplace_back([&, worker] {
                const auto range = range_for(worker, total_characters, workers);
                partial_counts[worker] =
                    count_range(texts, offsets, range.first, range.second);
            });
        }

        const auto main_range = range_for(0, total_characters, workers);
        partial_counts[0] =
            count_range(texts, offsets, main_range.first, main_range.second);

        for (std::thread& thread : threads) {
            thread.join();
        }
    }

    std::map<char, int> result;
    for (const Counts& counts : partial_counts) {
        for (std::size_t letter = 0; letter < counts.size(); ++letter) {
            if (counts[letter] != 0) {
                result[static_cast<char>('a' + letter)] +=
                    static_cast<int>(counts[letter]);
            }
        }
    }
    return result;
}

}  // namespace parallel_letter_frequency
