#if !defined(PARALLEL_LETTER_FREQUENCY_H)
#define PARALLEL_LETTER_FREQUENCY_H

#include <map>
#include <string_view>
#include <vector>

namespace parallel_letter_frequency {

// Counts the ASCII letters in all texts, ignoring case and all other
// characters. Only letters with a non-zero count appear in the result.
std::map<char, int> frequency(const std::vector<std::string_view>& texts);

}  // namespace parallel_letter_frequency

#endif
