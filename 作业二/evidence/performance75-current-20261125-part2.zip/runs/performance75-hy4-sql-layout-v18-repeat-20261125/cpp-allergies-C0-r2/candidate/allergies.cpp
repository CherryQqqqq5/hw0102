#include "allergies.h"

#include <array>

namespace allergies {

namespace {

struct Allergen {
    const char* name;
    unsigned int mask;
};

constexpr std::array<Allergen, 8> allergens{{
    {"eggs",        1U},
    {"peanuts",     2U},
    {"shellfish",   4U},
    {"strawberries", 8U},
    {"tomatoes",   16U},
    {"chocolate",  32U},
    {"pollen",     64U},
    {"cats",      128U},
}};

}  // namespace

allergy_test::allergy_test(unsigned int score) : score_(score) {
}

bool allergy_test::is_allergic_to(const std::string& allergen) const {
    for (const Allergen& candidate : allergens) {
        if (allergen == candidate.name) {
            return (score_ & candidate.mask) != 0U;
        }
    }
    return false;
}

std::unordered_set<std::string> allergy_test::get_allergies() const {
    std::unordered_set<std::string> result;
    for (const Allergen& allergen : allergens) {
        if ((score_ & allergen.mask) != 0U) {
            result.emplace(allergen.name);
        }
    }
    return result;
}

}  // namespace allergies
