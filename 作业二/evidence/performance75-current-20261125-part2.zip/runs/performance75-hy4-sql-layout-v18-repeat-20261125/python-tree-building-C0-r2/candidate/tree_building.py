"""Build a tree from records that contain only node and parent identifiers."""


INVALID_IDS_MESSAGE = "Record id is invalid or out of order."
INVALID_PARENT_MESSAGE = "Node parent_id should be smaller than it's record_id."
SELF_PARENT_MESSAGE = "Only root should have equal record and parent id."


class Record:
    def __init__(self, record_id, parent_id):
        self.record_id = record_id
        self.parent_id = parent_id


class Node:
    def __init__(self, node_id):
        self.node_id = node_id
        self.children = []


def BuildTree(records):
    """Reconstruct and return the tree described by ``records``.

    The records may be supplied in any order.  A valid input contains exactly
    one record for every id in ``range(len(records))``.  Every non-root record
    must name an earlier record as its parent, while the root (id 0) must be
    its own parent.
    """
    if not records:
        return None

    record_count = len(records)
    ordered_records = [None] * record_count

    # Index records by id without sorting or mutating the caller's list.
    for record in records:
        record_id = record.record_id
        if (
            not isinstance(record_id, int)
            or not 0 <= record_id < record_count
            or ordered_records[record_id] is not None
        ):
            raise ValueError(INVALID_IDS_MESSAGE)
        ordered_records[record_id] = record

    # Validate parent links before creating any nodes.
    for record in ordered_records:
        record_id = record.record_id
        parent_id = record.parent_id

        if record_id == parent_id:
            if record_id != 0:
                raise ValueError(SELF_PARENT_MESSAGE)
        elif not isinstance(parent_id, int) or not 0 <= parent_id < record_id:
            raise ValueError(INVALID_PARENT_MESSAGE)

    nodes = [None] * record_count
    root = None

    # Parents always have smaller ids, so each parent node exists by this point.
    for record in ordered_records:
        record_id = record.record_id
        parent_id = record.parent_id
        node = Node(record_id)
        nodes[record_id] = node

        if record_id == 0:
            root = node
        else:
            nodes[parent_id].children.append(node)

    return root
