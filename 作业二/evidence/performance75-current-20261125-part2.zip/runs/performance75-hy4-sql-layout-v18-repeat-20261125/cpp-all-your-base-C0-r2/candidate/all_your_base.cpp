#include "all_your_base.h"

#include <algorithm>
#include <cstdint>
#include <stdexcept>

namespace all_your_base {
namespace {

// A magnitude is stored least-significant limb first.  Using a limb base of
// 10^9 keeps every limb * base + carry below 2^64, even when a base is the
// largest representable unsigned int.
using limb_type = std::uint64_t;
constexpr limb_type limb_base = 1'000'000'000ULL;

void multiply_add(std::vector<limb_type> &magnitude,
                  unsigned int multiplier,
                  unsigned int addend) {
    limb_type carry = addend;
    for (limb_type &limb : magnitude) {
        const limb_type value = limb * multiplier + carry;
        limb = value % limb_base;
        carry = value / limb_base;
    }
    while (carry != 0) {
        magnitude.push_back(carry % limb_base);
        carry /= limb_base;
    }
}

unsigned int divide(std::vector<limb_type> &magnitude, unsigned int divisor) {
    limb_type remainder = 0;
    for (auto it = magnitude.rbegin(); it != magnitude.rend(); ++it) {
        const limb_type value = remainder * limb_base + *it;
        *it = value / divisor;
        remainder = value % divisor;
    }

    while (!magnitude.empty() && magnitude.back() == 0) {
        magnitude.pop_back();
    }

    return static_cast<unsigned int>(remainder);
}

}  // namespace

std::vector<unsigned int> convert(unsigned int from_base,
                                  const std::vector<unsigned int> &input_digits,
                                  unsigned int to_base) {
    if (from_base < 2 || to_base < 2) {
        throw std::invalid_argument("bases must be at least 2");
    }

    for (unsigned int digit : input_digits) {
        if (digit >= from_base) {
            throw std::invalid_argument("digit is not valid in the source base");
        }
    }

    std::vector<limb_type> magnitude;
    for (unsigned int digit : input_digits) {
        multiply_add(magnitude, from_base, digit);
    }

    std::vector<unsigned int> output_digits;
    while (!magnitude.empty()) {
        output_digits.push_back(divide(magnitude, to_base));
    }

    std::reverse(output_digits.begin(), output_digits.end());
    return output_digits;
}

}  // namespace all_your_base
