const BOOK_PRICE = 800;

// Extra price charged when a group grows from k - 1 to k different titles.
// Notice that the fifth title costs more than the fourth, which is why two
// groups of four can beat a group of five plus a group of three.
const GROUP_MARGINAL_PRICE = [BOOK_PRICE, 720, 640, 400, 440];

/**
 * Calculate the cheapest possible price for a basket of books.
 *
 * @param {Array<number|string>} books identifiers of books from one five-book series
 * @returns {number} total price in cents
 */
export const cost = (books) => {
  const copiesByTitle = new Map();

  for (const book of books) {
    copiesByTitle.set(book, (copiesByTitle.get(book) || 0) + 1);
  }

  const counts = Array.from(copiesByTitle.values())
    .sort((a, b) => b - a)
    .concat(Array(5 - copiesByTitle.size).fill(0))
    .slice(0, 5);

  // With sorted counts c1..c5, c[k] is also the number of groups containing
  // at least k titles in the most evenly packed grouping. The only grouping
  // change that ever lowers the price is exchanging one 5-group and one
  // 3-group for two 4-groups: it saves 440 - 400 = 40 cents. That exchange is
  // possible once for every copy of the fifth title while a third title can
  // still be added to a fourth-title group (c3 > c4).
  const exchanges = Math.min(counts[4], counts[2] - counts[3]);
  counts[3] += exchanges;
  counts[4] -= exchanges;

  return counts.reduce(
    (total, count, index) => total + count * GROUP_MARGINAL_PRICE[index],
    0,
  );
};
