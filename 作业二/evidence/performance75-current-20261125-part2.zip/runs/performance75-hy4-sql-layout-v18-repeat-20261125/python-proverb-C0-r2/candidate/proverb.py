def proverb(*pieces, qualifier=None):
    if not pieces:
        return []

    first, *rest = pieces
    lines = []
    previous = first
    for piece in rest:
        lines.append(f"For want of a {previous} the {piece} was lost.")
        previous = piece

    qualifier_with_space = f"{qualifier} " if qualifier else ""
    lines.append(f"And all for the want of a {qualifier_with_space}{first}.")
    return lines
