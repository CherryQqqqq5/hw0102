//
// Calculate the sum of all unique multiples of the given factors that are
// less than the supplied limit.
//
export const sum = (factors, limit) => {
  const multiples = new Set();

  for (const factor of factors) {
    // Zero (and any negative value) cannot contribute a useful finite series
    // of positive multiples below the limit.
    if (factor <= 0) {
      continue;
    }

    for (let multiple = factor; multiple < limit; multiple += factor) {
      multiples.add(multiple);
    }
  }

  let total = 0;
  for (const multiple of multiples) {
    total += multiple;
  }

  return total;
};
