//! A doubly linked list built from raw pointers.
//!
//! # Safety invariants
//!
//! A non-null link in a `LinkedList` always points to a heap allocation made by
//! `Box::into_raw`.  For every list:
//!
//! * `head` is null exactly when `tail` is null and `len == 0`;
//! * all nodes from `head` to `tail` are linked by consistent `next`/`prev`
//!   pointers, and null `next`/`prev` mean the list ends;
//! * every node is owned by exactly one `LinkedList` and is deallocated once,
//!   either by `Cursor::take` or by `LinkedList::drop`;
//! * while a `Cursor` or `Iter` exists, the compiler-guaranteed borrow of the
//!   list prevents the node graph from being changed through another path.
//!
//! Links are stored as `*const Node<T>` (rather than `*mut`) so that
//! `LinkedList` and `Iter` are covariant in `T`.  They are cast back to `*mut`
//! only inside unsafe blocks where the caller can prove exclusive access.

mod pre_implemented;

use std::marker::PhantomData;
use std::ptr;

struct Node<T> {
    elem: T,
    next: *const Node<T>,
    prev: *const Node<T>,
}

impl<T> Node<T> {
    /// Allocate a detached node.  This operation itself is safe: the returned
    /// pointer is uniquely owned by the caller until it is linked into a list
    /// or passed back to `Box::from_raw`.
    fn new(elem: T, prev: *const Node<T>, next: *const Node<T>) -> *const Node<T> {
        Box::into_raw(Box::new(Node { elem, prev, next })) as *const Node<T>
    }
}

/// A doubly linked list.
///
/// The raw pointers are not `Send`/`Sync` automatically.  The manual impls
/// below expose list sharing only when the contained `T` is safe to share.
pub struct LinkedList<T> {
    head: *const Node<T>,
    tail: *const Node<T>,
    len: usize,
    // PhantomData models ownership of the nodes for drop checking and keeps
    // the covariance coming from `*const Node<T>` explicit.
    _marker: PhantomData<T>,
}

/// A position inside a list.  A null `current` means the list is empty.
/// Insertions do not move the cursor; removals move it toward the back.
pub struct Cursor<'a, T> {
    list: &'a mut LinkedList<T>,
    current: *const Node<T>,
}

/// An immutable iterator from the front of a list to its back.
pub struct Iter<'a, T> {
    next: *const Node<T>,
    _marker: PhantomData<&'a T>,
}

impl<T> LinkedList<T> {
    pub fn new() -> Self {
        Self {
            head: ptr::null(),
            tail: ptr::null(),
            len: 0,
            _marker: PhantomData,
        }
    }

    // You may be wondering why it's necessary to have is_empty()
    // when it can easily be determined from len().
    // It's good custom to have both because len() can be expensive for some types,
    // whereas is_empty() is almost always cheap.
    // (Also ask yourself whether len() is expensive for LinkedList)
    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    pub fn len(&self) -> usize {
        self.len
    }

    /// Return a cursor positioned on the front element
    pub fn cursor_front(&mut self) -> Cursor<'_, T> {
        let current = self.head;
        Cursor {
            list: self,
            current,
        }
    }

    /// Return a cursor positioned on the back element
    pub fn cursor_back(&mut self) -> Cursor<'_, T> {
        let current = self.tail;
        Cursor {
            list: self,
            current,
        }
    }

    /// Return an iterator that moves from front to back
    pub fn iter(&self) -> Iter<'_, T> {
        Iter {
            next: self.head,
            _marker: PhantomData,
        }
    }
}

impl<T> Default for LinkedList<T> {
    fn default() -> Self {
        Self::new()
    }
}

// The cursor is expected to act as if it is at the position of an element
// and it also has to work with and be able to insert into an empty list.
impl<T> Cursor<'_, T> {
    /// Take a mutable reference to the current element
    pub fn peek_mut(&mut self) -> Option<&mut T> {
        if self.current.is_null() {
            return None;
        }

        // SAFETY: a non-null `current` points to a live node owned by this
        // list.  The cursor holds `&mut LinkedList`, so no other reference to
        // the node's element can be live while the returned `&mut T` exists.
        Some(unsafe { &mut (*(self.current as *mut Node<T>)).elem })
    }

    /// Move one position forward (towards the back) and
    /// return a reference to the new position
    #[allow(clippy::should_implement_trait)]
    pub fn next(&mut self) -> Option<&mut T> {
        if self.current.is_null() {
            return None;
        }

        // SAFETY: `current` is a non-null link from this list, hence a live
        // node.  Reading its `next` link cannot invalidate it.
        let next = unsafe { (*self.current).next };
        if next.is_null() {
            return None;
        }

        self.current = next;
        self.peek_mut()
    }

    /// Move one position backward (towards the front) and
    /// return a reference to the new position
    pub fn prev(&mut self) -> Option<&mut T> {
        if self.current.is_null() {
            return None;
        }

        // SAFETY: `current` is a non-null link from this list, hence a live
        // node.  Reading its `prev` link cannot invalidate it.
        let prev = unsafe { (*self.current).prev };
        if prev.is_null() {
            return None;
        }

        self.current = prev;
        self.peek_mut()
    }

    /// Remove and return the element at the current position and move the cursor
    /// to the neighboring element that's closest to the back. This can be
    /// either the next or previous position.
    pub fn take(&mut self) -> Option<T> {
        if self.current.is_null() {
            return None;
        }

        let node = self.current as *mut Node<T>;

        // SAFETY: `current` is a live node owned by this list.  The cursor's
        // `&mut LinkedList` gives exclusive access, so the links and the
        // element may be moved out.  We repair all incoming links and the
        // list's head/tail before dropping the box, and we never visit the
        // removed node afterwards.
        unsafe {
            let prev = (*node).prev;
            let next = (*node).next;

            if prev.is_null() {
                self.list.head = next;
            } else {
                (*(prev as *mut Node<T>)).next = next;
            }

            if next.is_null() {
                self.list.tail = prev;
            } else {
                (*(next as *mut Node<T>)).prev = prev;
            }

            // The successor is closer to the back; when removing the tail,
            // the predecessor is the closest remaining neighbor.
            self.current = if next.is_null() { prev } else { next };
            self.list.len -= 1;

            let boxed = Box::from_raw(node);
            Some(boxed.elem)
        }
    }

    pub fn insert_after(&mut self, element: T) {
        if self.current.is_null() {
            // SAFETY: a null cursor can only occur for an empty list, which
            // is exactly the precondition of `insert_into_empty`.
            unsafe { self.insert_into_empty(element) };
            return;
        }

        let current = self.current as *mut Node<T>;

        // SAFETY: `current` is a live node owned by this list and the cursor
        // holds `&mut LinkedList`.  `new_node` is fresh and uniquely owned, so
        // splicing it between `current` and its successor preserves all list
        // invariants.  The cursor deliberately remains on `current`.
        unsafe {
            let old_next = (*current).next;
            let new_node = Node::new(element, self.current, old_next) as *mut Node<T>;

            if old_next.is_null() {
                self.list.tail = new_node as *const Node<T>;
            } else {
                (*(old_next as *mut Node<T>)).prev = new_node as *const Node<T>;
            }
            (*current).next = new_node as *const Node<T>;
            self.list.len += 1;
        }
    }

    pub fn insert_before(&mut self, element: T) {
        if self.current.is_null() {
            // SAFETY: a null cursor can only occur for an empty list, which
            // is exactly the precondition of `insert_into_empty`.
            unsafe { self.insert_into_empty(element) };
            return;
        }

        let current = self.current as *mut Node<T>;

        // SAFETY: `current` is a live node owned by this list and the cursor
        // holds `&mut LinkedList`.  `new_node` is fresh and uniquely owned, so
        // splicing it between `current` and its predecessor preserves all list
        // invariants.  The cursor deliberately remains on `current`.
        unsafe {
            let old_prev = (*current).prev;
            let new_node = Node::new(element, old_prev, self.current) as *mut Node<T>;

            if old_prev.is_null() {
                self.list.head = new_node as *const Node<T>;
            } else {
                (*(old_prev as *mut Node<T>)).next = new_node as *const Node<T>;
            }
            (*current).prev = new_node as *const Node<T>;
            self.list.len += 1;
        }
    }

    /// Insert the only node of an empty list and put the cursor on it.
    ///
    /// # Safety
    ///
    /// The caller must guarantee that the cursor is null, the list has no
    /// head/tail, and its length is zero.
    unsafe fn insert_into_empty(&mut self, element: T) {
        debug_assert!(self.current.is_null());
        debug_assert!(self.list.head.is_null());
        debug_assert!(self.list.tail.is_null());
        debug_assert_eq!(self.list.len, 0);

        // SAFETY: the caller guarantees the list is empty.  A fresh node with
        // no links becomes both ends, and the cursor is moved onto it so a
        // second insertion on the same cursor has a well-defined position.
        let new_node = Node::new(element, ptr::null(), ptr::null());
        self.list.head = new_node;
        self.list.tail = new_node;
        self.current = new_node;
        self.list.len = 1;
    }
}

impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    fn next(&mut self) -> Option<&'a T> {
        if self.next.is_null() {
            return None;
        }

        let node = self.next;

        // SAFETY: `node` is a live node reached from the borrowed list, and
        // `Iter<'a, T>` ties the returned reference to that borrow.  Advancing
        // the raw pointer only reads the immutable `next` link.
        unsafe {
            self.next = (*node).next;
            Some(&(*node).elem)
        }
    }
}

// SAFETY: moving a `LinkedList<T>` moves ownership of its node graph.  No
// other list or thread can access those nodes, and `T: Send` allows the
// contained values to be moved to another thread.
unsafe impl<T: Send> Send for LinkedList<T> {}

// SAFETY: with `T: Sync`, shared references to every element are safe to use
// from multiple threads.  The list's `&self` API only exposes immutable
// iteration and references; mutation requires `&mut self` (or a `Cursor`),
// which cannot be shared across threads.
unsafe impl<T: Sync> Sync for LinkedList<T> {}

impl<T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        let mut current = self.head;

        while !current.is_null() {
            // SAFETY: `current` is a live node owned by this list.  Copying
            // `next` before freeing keeps it valid for the following step.
            let next = unsafe { (*current).next };

            // SAFETY: every node came from `Box::into_raw` and is visited
            // exactly once on this traversal, so reconstructing and dropping
            // its box deallocates it and its element once.
            unsafe {
                drop(Box::from_raw(current as *mut Node<T>));
            }

            current = next;
        }

        self.head = ptr::null();
        self.tail = ptr::null();
        self.len = 0;
    }
}
