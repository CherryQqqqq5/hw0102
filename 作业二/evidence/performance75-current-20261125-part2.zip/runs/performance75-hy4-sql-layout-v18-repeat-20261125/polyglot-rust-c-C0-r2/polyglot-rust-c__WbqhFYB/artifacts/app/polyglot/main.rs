/*/**/
#if 0
// */
fn add_decimal(a: &[u8], b: &[u8]) -> Vec<u8> {
    let n = a.len().max(b.len());
    let mut out = Vec::with_capacity(n + 1);
    let mut carry: u8 = 0;
    for i in 0..n {
        let x = if i < a.len() { a[a.len() - 1 - i] - b'0' } else { 0 };
        let y = if i < b.len() { b[b.len() - 1 - i] - b'0' } else { 0 };
        let s = x + y + carry;
        out.push(b'0' + (s % 10));
        carry = s / 10;
    }
    if carry != 0 {
        out.push(b'0' + carry);
    }
    out.reverse();
    out
}

fn main() {
    let n: usize = std::env::args()
        .nth(1)
        .and_then(|s| s.parse().ok())
        .unwrap_or(0);

    let mut a: Vec<u8> = vec![b'1'];
    if n == 0 {
        println!("{}", String::from_utf8(a).unwrap());
        return;
    }

    let mut b: Vec<u8> = vec![b'1'];
    for _ in 1..n {
        let c = add_decimal(&a, &b);
        a = b;
        b = c;
    }
    println!("{}", String::from_utf8(b).unwrap());
}
/*/**/
#endif
// */
/*/**/
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <string>

static std::string add_decimal(const std::string& a, const std::string& b) {
    std::string out;
    out.reserve(std::max(a.size(), b.size()) + 1);
    std::size_t i = a.size();
    std::size_t j = b.size();
    int carry = 0;
    while (i > 0 || j > 0 || carry != 0) {
        int sum = carry;
        if (i > 0) sum += a[--i] - '0';
        if (j > 0) sum += b[--j] - '0';
        out.push_back(static_cast<char>('0' + (sum % 10)));
        carry = sum / 10;
    }
    std::reverse(out.begin(), out.end());
    return out;
}

int main(int argc, char** argv) {
    unsigned long long n = 0;
    if (argc > 1) {
        n = std::strtoull(argv[1], nullptr, 10);
    }

    std::string a = "1";
    if (n == 0) {
        std::cout << a << '\n';
        return 0;
    }

    std::string b = "1";
    for (unsigned long long i = 1; i < n; ++i) {
        std::string c = add_decimal(a, b);
        a = b;
        b = c;
    }
    std::cout << b << '\n';
    return 0;
}
// */
