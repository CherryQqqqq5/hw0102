#pragma once

#include <cstddef>
#include <stdexcept>
#include <utility>

namespace linked_list {

template <typename T>
class List {
   private:
    struct Node {
        T value;
        Node* previous;
        Node* next;

        Node(const T& value, Node* previous, Node* next)
            : value(value), previous(previous), next(next) {}

        Node(T&& value, Node* previous, Node* next)
            : value(std::move(value)), previous(previous), next(next) {}
    };

    Node* head_;
    Node* tail_;
    std::size_t size_;

    void delete_all_nodes() noexcept {
        while (head_ != nullptr) {
            Node* const next = head_->next;
            delete head_;
            head_ = next;
        }
        tail_ = nullptr;
        size_ = 0;
    }

   public:
    List() noexcept : head_(nullptr), tail_(nullptr), size_(0) {}

    List(const List& other) : head_(nullptr), tail_(nullptr), size_(0) {
        for (Node* current = other.head_; current != nullptr;
             current = current->next) {
            push(current->value);
        }
    }

    List(List&& other) noexcept
        : head_(other.head_), tail_(other.tail_), size_(other.size_) {
        other.head_ = nullptr;
        other.tail_ = nullptr;
        other.size_ = 0;
    }

    List& operator=(const List& other) {
        if (this != &other) {
            List copy(other);
            swap(copy);
        }
        return *this;
    }

    List& operator=(List&& other) noexcept {
        if (this != &other) {
            delete_all_nodes();
            head_ = other.head_;
            tail_ = other.tail_;
            size_ = other.size_;
            other.head_ = nullptr;
            other.tail_ = nullptr;
            other.size_ = 0;
        }
        return *this;
    }

    ~List() { delete_all_nodes(); }

    void swap(List& other) noexcept {
        using std::swap;
        swap(head_, other.head_);
        swap(tail_, other.tail_);
        swap(size_, other.size_);
    }

    void push(T value) {
        Node* const node = new Node(std::move(value), tail_, nullptr);
        if (tail_ != nullptr) {
            tail_->next = node;
        } else {
            head_ = node;
        }
        tail_ = node;
        ++size_;
    }

    void unshift(T value) {
        Node* const node = new Node(std::move(value), nullptr, head_);
        if (head_ != nullptr) {
            head_->previous = node;
        } else {
            tail_ = node;
        }
        head_ = node;
        ++size_;
    }

    T pop() {
        if (tail_ == nullptr) {
            throw std::out_of_range("pop() called on an empty List");
        }

        Node* const node = tail_;
        T value = std::move(node->value);
        tail_ = node->previous;
        if (tail_ != nullptr) {
            tail_->next = nullptr;
        } else {
            head_ = nullptr;
        }
        delete node;
        --size_;
        return value;
    }

    T shift() {
        if (head_ == nullptr) {
            throw std::out_of_range("shift() called on an empty List");
        }

        Node* const node = head_;
        T value = std::move(node->value);
        head_ = node->next;
        if (head_ != nullptr) {
            head_->previous = nullptr;
        } else {
            tail_ = nullptr;
        }
        delete node;
        --size_;
        return value;
    }

    std::size_t count() const noexcept { return size_; }

    bool erase(const T& value) {
        for (Node* current = head_; current != nullptr; current = current->next) {
            if (current->value == value) {
                Node* const previous = current->previous;
                Node* const next = current->next;

                if (previous != nullptr) {
                    previous->next = next;
                } else {
                    head_ = next;
                }

                if (next != nullptr) {
                    next->previous = previous;
                } else {
                    tail_ = previous;
                }

                delete current;
                --size_;
                return true;
            }
        }
        return false;
    }
};

template <typename T>
void swap(List<T>& left, List<T>& right) noexcept {
    left.swap(right);
}

}  // namespace linked_list
