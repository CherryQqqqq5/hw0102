package connect

import (
	"fmt"
	"strings"
)

// ResultOf returns the winner of a Hex board, or an empty string when
// neither player has connected their two sides.
//
// O wins by joining the top and bottom edges; X wins by joining the left
// and right edges. Rows are represented in the usual slanted form: a cell
// at (row, column) touches the cells at
//
//	(row, column-1), (row, column+1),
//	(row-1, column), (row-1, column+1),
//	(row+1, column-1), (row+1, column).
func ResultOf(lines []string) (string, error) {
	board, err := parseBoard(lines)
	if err != nil {
		return "", err
	}

	if connected(board, 'X', false) {
		return "X", nil
	}
	if connected(board, 'O', true) {
		return "O", nil
	}
	return "", nil
}

// parseBoard removes the readability whitespace used in board diagrams and
// validates that every row describes the same rectangular coordinate grid.
func parseBoard(lines []string) ([][]byte, error) {
	board := make([][]byte, len(lines))
	for i, line := range lines {
		cells := []byte(strings.ReplaceAll(line, " ", ""))
		for _, cell := range cells {
			if cell != '.' && cell != 'X' && cell != 'O' {
				return nil, fmt.Errorf("invalid cell %q on row %d", cell, i)
			}
		}
		board[i] = cells
	}

	if len(board) == 0 {
		return board, nil
	}

	width := len(board[0])
	for i := 1; i < len(board); i++ {
		if len(board[i]) != width {
			return nil, fmt.Errorf("row %d has %d cells, want %d", i, len(board[i]), width)
		}
	}

	return board, nil
}

var neighbours = [6][2]int{
	{0, -1}, {0, 1},
	{-1, 0}, {-1, 1},
	{1, -1}, {1, 0},
}

// connected reports whether player has a path between the two sides named
// by its symbol. vertical selects O's top-to-bottom connection; otherwise
// X's left-to-right connection is tested.
func connected(board [][]byte, player byte, vertical bool) bool {
	rows := len(board)
	if rows == 0 {
		return false
	}
	cols := len(board[0])

	seen := make([][]bool, rows)
	for row := range seen {
		seen[row] = make([]bool, cols)
	}

	type cell struct{ row, col int }
	stack := make([]cell, 0, rows+cols)

	var add func(int, int)
	add = func(row, col int) {
		if row < 0 || row >= rows || col < 0 || col >= cols {
			return
		}
		if seen[row][col] || board[row][col] != player {
			return
		}
		seen[row][col] = true
		stack = append(stack, cell{row, col})
	}

	if vertical {
		for col := 0; col < cols; col++ {
			add(0, col)
		}
	} else {
		for row := 0; row < rows; row++ {
			add(row, 0)
		}
	}

	for len(stack) > 0 {
		last := len(stack) - 1
		current := stack[last]
		stack = stack[:last]

		if (vertical && current.row == rows-1) || (!vertical && current.col == cols-1) {
			return true
		}

		for _, delta := range neighbours {
			add(current.row+delta[0], current.col+delta[1])
		}
	}

	return false
}
