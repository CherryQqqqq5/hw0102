const ENTITIES = [
  'house that Jack built.',
  'malt',
  'rat',
  'cat',
  'dog',
  'cow with the crumpled horn',
  'maiden all forlorn',
  'man all tattered and torn',
  'priest all shaven and shorn',
  'rooster that crowed in the morn',
  'farmer sowing his corn',
  'horse and the hound and the horn',
];

const ACTIONS = [
  null,
  'lay in',
  'ate',
  'killed',
  'worried',
  'tossed',
  'milked',
  'kissed',
  'married',
  'woke',
  'kept',
  'belonged to',
];

export class House {
  static verse(verseNumber) {
    if (!Number.isInteger(verseNumber)
      || verseNumber < 1
      || verseNumber > ENTITIES.length) {
      throw new RangeError(`Verse must be between 1 and ${ENTITIES.length}.`);
    }

    const lines = [`This is the ${ENTITIES[verseNumber - 1]}`];

    for (let index = verseNumber - 1; index > 0; index -= 1) {
      lines.push(`that ${ACTIONS[index]} the ${ENTITIES[index - 1]}`);
    }

    return lines;
  }

  static verses(firstVerse, lastVerse) {
    if (!Number.isInteger(firstVerse)
      || !Number.isInteger(lastVerse)
      || firstVerse < 1
      || lastVerse > ENTITIES.length
      || firstVerse > lastVerse) {
      throw new RangeError(`Verses must be a valid range from 1 to ${ENTITIES.length}.`);
    }

    const lyrics = [];

    for (let verseNumber = firstVerse; verseNumber <= lastVerse; verseNumber += 1) {
      if (lyrics.length > 0) {
        lyrics.push('');
      }
      lyrics.push(...House.verse(verseNumber));
    }

    return lyrics;
  }
}
