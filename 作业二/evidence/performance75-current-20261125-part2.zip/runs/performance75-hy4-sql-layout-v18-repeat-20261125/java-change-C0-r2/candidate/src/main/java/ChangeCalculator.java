import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

class ChangeCalculator {

    private final List<Integer> currencyCoins;

    ChangeCalculator(List<Integer> currencyCoins) {
        if (currencyCoins == null) {
            throw new IllegalArgumentException("Currency coins cannot be null.");
        }

        List<Integer> coins = new ArrayList<>();
        for (Integer coin : currencyCoins) {
            if (coin == null) {
                throw new IllegalArgumentException("Coin values cannot be null.");
            }
            if (coin > 0 && !coins.contains(coin)) {
                coins.add(coin);
            }
        }
        Collections.sort(coins);
        this.currencyCoins = Collections.unmodifiableList(coins);
    }

    List<Integer> computeMostEfficientChange(int grandTotal) {
        if (grandTotal < 0) {
            throw new IllegalArgumentException("Negative totals are not allowed.");
        }
        if (grandTotal == Integer.MAX_VALUE) {
            throw new IllegalArgumentException(
                    "The total " + grandTotal + " cannot be represented in the given currency.");
        }

        int[] minimumCoins = new int[grandTotal + 1];
        int[] selectedCoin = new int[grandTotal + 1];
        Arrays.fill(minimumCoins, 1, minimumCoins.length, Integer.MAX_VALUE);

        for (int amount = 1; amount <= grandTotal; amount++) {
            for (int coin : currencyCoins) {
                if (coin > amount) {
                    break;
                }

                int remainder = amount - coin;
                if (minimumCoins[remainder] == Integer.MAX_VALUE) {
                    continue;
                }

                int candidateCoinCount = minimumCoins[remainder] + 1;
                if (candidateCoinCount < minimumCoins[amount]) {
                    minimumCoins[amount] = candidateCoinCount;
                    selectedCoin[amount] = coin;
                }
            }
        }

        if (minimumCoins[grandTotal] == Integer.MAX_VALUE) {
            throw new IllegalArgumentException(
                    "The total " + grandTotal + " cannot be represented in the given currency.");
        }

        List<Integer> change = new ArrayList<>();
        int remaining = grandTotal;
        while (remaining > 0) {
            int coin = selectedCoin[remaining];
            change.add(coin);
            remaining -= coin;
        }
        Collections.sort(change);
        return change;
    }
}
