#!/usr/bin/env node
'use strict';

const fs = require('fs');

function fail(message) {
  process.stderr.write(String(message) + '\n');
  process.exit(1);
}

if (process.argv.length < 3) fail('usage: node extract.js <elf-file>');

const path = process.argv[2];
const buf = fs.readFileSync(path);

if (buf.length < 16 || buf[0] !== 0x7f || buf[1] !== 0x45 || buf[2] !== 0x4c || buf[3] !== 0x46) {
  fail('not an ELF file');
}

const elfClass = buf[4];       // 1 = ELF32, 2 = ELF64
const elfData = buf[5];        // 1 = little endian, 2 = big endian
const little = elfData === 1;

if (elfClass !== 1 && elfClass !== 2) fail('unsupported ELF class');
if (elfData !== 1 && elfData !== 2) fail('unsupported ELF byte order');

function readU16(off) {
  if (off + 2 > buf.length) fail('truncated ELF header');
  return little ? buf.readUInt16LE(off) : buf.readUInt16BE(off);
}

function readU32(off) {
  if (off + 4 > buf.length) fail('truncated ELF header');
  return little ? buf.readUInt32LE(off) : buf.readUInt32BE(off);
}

function readUint(off, is64) {
  if (!is64) return BigInt(readU32(off));
  if (off + 8 > buf.length) fail('truncated ELF header');
  return little ? buf.readBigUInt64LE(off) : buf.readBigUInt64BE(off);
}

function toSafeNumber(value, what) {
  if (value > BigInt(Number.MAX_SAFE_INTEGER)) fail(what + ' is too large');
  return Number(value);
}

const is64 = elfClass === 2;
const phoff = toSafeNumber(readUint(is64 ? 32 : 28, is64), 'program header offset');
const phentsize = readU16(is64 ? 54 : 42);
const phnum = readU16(is64 ? 56 : 44);

if (phentsize === 0) fail('invalid program header entry size');

const out = Object.create(null);

function readWord(fileOffset, fileSize, offsetInSegment) {
  const available = Math.max(0, Math.min(4, fileSize - offsetInSegment));
  const word = Buffer.alloc(4);
  if (available > 0) {
    const start = fileOffset + offsetInSegment;
    if (start + available > buf.length) fail('truncated PT_LOAD segment data');
    buf.copy(word, 0, start, start + available);
  }
  return little ? word.readUInt32LE(0) : word.readUInt32BE(0);
}

for (let i = 0; i < phnum; ++i) {
  const ph = phoff + i * phentsize;
  if (ph + (is64 ? 56 : 32) > buf.length) fail('truncated program header table');

  const pType = readU32(ph);
  if (pType !== 1) continue; // PT_LOAD

  let pOffset, pVaddr, pFilesz, pMemsz;
  if (is64) {
    pOffset = toSafeNumber(readUint(ph + 8, true), 'p_offset');
    pVaddr = readUint(ph + 16, true);
    pFilesz = toSafeNumber(readUint(ph + 32, true), 'p_filesz');
    pMemsz = toSafeNumber(readUint(ph + 40, true), 'p_memsz');
  } else {
    pOffset = toSafeNumber(readUint(ph + 4, false), 'p_offset');
    pVaddr = readUint(ph + 8, false);
    pFilesz = toSafeNumber(readUint(ph + 16, false), 'p_filesz');
    pMemsz = toSafeNumber(readUint(ph + 20, false), 'p_memsz');
  }

  for (let offset = 0; offset + 3 < pMemsz; offset += 4) {
    const address = (pVaddr + BigInt(offset)).toString();
    out[address] = readWord(pOffset, pFilesz, offset);
  }
}

process.stdout.write(JSON.stringify(out));
