"""A small, simplified implementation of the Unix grep utility."""


def grep(pattern, flags, files):
    """Return matching lines from ``files`` for the fixed string ``pattern``.

    ``flags`` is a string containing zero or more space-separated options:
    ``-n`` (line numbers), ``-l`` (file names only), ``-i`` (case insensitive),
    ``-v`` (invert the match), and ``-x`` (match the whole line).
    """
    if isinstance(flags, str):
        flag_set = set(flags.split())
    else:
        flag_set = set(flags or ())

    show_line_numbers = "-n" in flag_set
    show_file_names = "-l" in flag_set
    case_insensitive = "-i" in flag_set
    invert = "-v" in flag_set
    exact = "-x" in flag_set

    multiple_files = len(files) > 1
    needle = pattern.casefold() if case_insensitive else pattern
    results = []

    for file_name in files:
        found_in_file = False

        with open(file_name) as file:
            for line_number, line in enumerate(file, start=1):
                line_text = line.rstrip("\r\n")
                candidate = (
                    line_text.casefold() if case_insensitive else line_text
                )

                if exact:
                    matched = candidate == needle
                else:
                    matched = needle in candidate

                if invert:
                    matched = not matched

                if not matched:
                    continue

                if show_file_names:
                    found_in_file = True
                    break

                pieces = []
                if multiple_files:
                    pieces.append(str(file_name))
                if show_line_numbers:
                    pieces.append(str(line_number))
                pieces.append(line_text)
                results.append(":".join(pieces) + "\n")

        if show_file_names and found_in_file:
            results.append(str(file_name) + "\n")

    return "".join(results)
