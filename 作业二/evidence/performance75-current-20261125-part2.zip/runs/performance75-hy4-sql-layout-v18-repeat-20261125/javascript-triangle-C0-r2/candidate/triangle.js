export class Triangle {
  constructor(...sides) {
    const [a, b, c] = sides;

    this.sides = sides;
    this.isValid = sides.length === 3 &&
      sides.every((side) => side > 0) &&
      a + b >= c &&
      b + c >= a &&
      a + c >= b;
  }

  get isEquilateral() {
    const [a, b, c] = this.sides;

    return this.isValid && a === b && b === c;
  }

  get isIsosceles() {
    const [a, b, c] = this.sides;

    return this.isValid && (a === b || b === c || a === c);
  }

  get isScalene() {
    const [a, b, c] = this.sides;

    return this.isValid && a !== b && b !== c && a !== c;
  }
}
