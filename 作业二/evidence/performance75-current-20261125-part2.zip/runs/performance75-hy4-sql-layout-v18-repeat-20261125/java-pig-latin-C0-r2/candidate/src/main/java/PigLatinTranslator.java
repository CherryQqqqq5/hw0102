class PigLatinTranslator {
    public String translate(String text) {
        StringBuilder result = new StringBuilder();
        int index = 0;

        while (index < text.length()) {
            int wordStart = index;
            while (index < text.length() && !Character.isWhitespace(text.charAt(index))) {
                index++;
            }
            if (wordStart < index) {
                result.append(translateWord(text.substring(wordStart, index)));
            }
            while (index < text.length() && Character.isWhitespace(text.charAt(index))) {
                result.append(text.charAt(index));
                index++;
            }
        }

        return result.toString();
    }

    private String translateWord(String word) {
        if (startsWithVowelSound(word)) {
            return word + "ay";
        }

        int splitAt = findSplitIndex(word);
        return word.substring(splitAt) + word.substring(0, splitAt) + "ay";
    }

    private boolean startsWithVowelSound(String word) {
        if (word.length() == 0) {
            return false;
        }
        if (isVowel(word.charAt(0))) {
            return true;
        }
        return word.length() >= 2
                && ((word.charAt(0) == 'x' && word.charAt(1) == 'r')
                    || (word.charAt(0) == 'y' && word.charAt(1) == 't'));
    }

    private int findSplitIndex(String word) {
        int index = 0;
        while (index < word.length()) {
            char current = word.charAt(index);

            if (isVowel(current) || (current == 'y' && index > 0)) {
                return index;
            }

            if (current == 'q' && index + 1 < word.length() && word.charAt(index + 1) == 'u') {
                index += 2;
            } else {
                index++;
            }
        }

        return word.length();
    }

    private boolean isVowel(char letter) {
        return letter == 'a' || letter == 'e' || letter == 'i'
                || letter == 'o' || letter == 'u';
    }
}
