package beer

import (
	"errors"
	"fmt"
	"strings"
)

const (
	minBottles = 0
	maxBottles = 99
)

// Song returns all 100 verses of the song.
func Song() string {
	song, _ := Verses(maxBottles, minBottles)
	return song
}

// Verses returns the verses from start down to stop, inclusive.
func Verses(start, stop int) (string, error) {
	if start < minBottles || start > maxBottles {
		return "", errors.New("start verse must be between 0 and 99")
	}
	if stop < minBottles || stop > maxBottles {
		return "", errors.New("stop verse must be between 0 and 99")
	}
	if start < stop {
		return "", errors.New("start verse must not be less than stop verse")
	}

	var song strings.Builder
	for n := start; n >= stop; n-- {
		verse, err := Verse(n)
		if err != nil {
			return "", err
		}
		song.WriteString(verse)
		song.WriteString("\n")
	}
	return song.String(), nil
}

// Verse returns a single verse for n bottles.
func Verse(n int) (string, error) {
	if n < minBottles || n > maxBottles {
		return "", errors.New("verse must be between 0 and 99")
	}

	next := n - 1
	action := "Take one down and pass it around"
	switch n {
	case 0:
		next = maxBottles
		action = "Go to the store and buy some more"
	case 1:
		action = "Take it down and pass it around"
	}

	return fmt.Sprintf(
		"%s of beer on the wall, %s of beer.\n%s, %s of beer on the wall.\n",
		upperFirst(bottles(n)), bottles(n), action, bottles(next),
	), nil
}

func bottles(n int) string {
	switch n {
	case 0:
		return "no more bottles"
	case 1:
		return "1 bottle"
	default:
		return fmt.Sprintf("%d bottles", n)
	}
}

func upperFirst(s string) string {
	return strings.ToUpper(s[:1]) + s[1:]
}
