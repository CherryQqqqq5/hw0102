"""A small in-memory RESTful API for tracking IOUs."""

import json


ZERO_TOLERANCE = 1e-12


class RestAPI:
    def __init__(self, database=None):
        if database is None:
            database = {"users": []}
        if "users" not in database:
            database["users"] = []
        self.database = database

    def get(self, url, payload=None):
        if url != "/users":
            return json.dumps({})

        data = self._payload_data(payload)
        requested = data.get("users") if isinstance(data, dict) else None

        if requested is None:
            users = [self._user_view(user) for user in self.database["users"]]
        else:
            names = set(requested)
            users = [
                self._user_view(user)
                for user in self.database["users"]
                if user.get("name") in names
            ]
            users.sort(key=lambda user: user["name"])

        return json.dumps({"users": users})

    def post(self, url, payload=None):
        data = self._payload_data(payload)
        if not isinstance(data, dict):
            return json.dumps({})

        if url == "/add":
            name = data["user"]
            user = self._find_user(name, required=False)
            if user is None:
                user = {"name": name, "owes": {}, "owed_by": {}, "balance": 0.0}
                self.database["users"].append(user)
            return json.dumps(self._user_view(user))

        if url == "/iou":
            lender = self._find_user(data["lender"])
            borrower = self._find_user(data["borrower"])
            self._apply_iou(lender, borrower, float(data["amount"]))
            self._sync_relationships()
            affected = {lender["name"], borrower["name"]}
            users = [
                self._user_view(user)
                for user in self.database["users"]
                if user["name"] in affected
            ]
            users.sort(key=lambda user: user["name"])
            return json.dumps({"users": users})

        return json.dumps({})

    @staticmethod
    def _payload_data(payload):
        if payload is None:
            return {}
        if isinstance(payload, (str, bytes, bytearray)):
            return json.loads(payload)
        return payload

    def _find_user(self, name, required=True):
        for user in self.database["users"]:
            if user.get("name") == name:
                return user
        if required:
            raise ValueError("unknown user: {}".format(name))
        return None

    @staticmethod
    def _set_debt(user, other_name, amount):
        debts = user.setdefault("owes", {})
        if abs(amount) <= ZERO_TOLERANCE:
            debts.pop(other_name, None)
        else:
            debts[other_name] = float(amount)

    @classmethod
    def _apply_iou(cls, lender, borrower, amount):
        """Record a loan from lender to borrower, netting reciprocal debts."""
        if amount < 0:
            raise ValueError("amount must be non-negative")

        lender_name = lender["name"]
        borrower_name = borrower["name"]
        lender_owes = float(lender.get("owes", {}).get(borrower_name, 0.0))
        borrower_owes = float(borrower.get("owes", {}).get(lender_name, 0.0))

        # A loan makes the borrower owe the lender, so it reduces any existing
        # debt running in the opposite direction before creating a new one.
        net = lender_owes - borrower_owes - amount
        if net > ZERO_TOLERANCE:
            cls._set_debt(lender, borrower_name, net)
            cls._set_debt(borrower, lender_name, 0.0)
        elif net < -ZERO_TOLERANCE:
            cls._set_debt(lender, borrower_name, 0.0)
            cls._set_debt(borrower, lender_name, -net)
        else:
            cls._set_debt(lender, borrower_name, 0.0)
            cls._set_debt(borrower, lender_name, 0.0)

    def _sync_relationships(self):
        """Rebuild owed_by maps and balances from the owes maps."""
        users = self.database["users"]
        for user in users:
            user["owed_by"] = {}

        for debtor in users:
            debts = debtor.setdefault("owes", {})
            for creditor_name in list(debts):
                amount = float(debts[creditor_name])
                if abs(amount) <= ZERO_TOLERANCE:
                    del debts[creditor_name]
                    continue
                debts[creditor_name] = amount
                creditor = self._find_user(creditor_name, required=False)
                if creditor is not None:
                    creditor["owed_by"][debtor["name"]] = amount

        for user in users:
            owes = user.setdefault("owes", {})
            owed_by = user.get("owed_by", {})
            user["balance"] = float(sum(owed_by.values()) - sum(owes.values()))

    @staticmethod
    def _user_view(user):
        return {
            "name": user["name"],
            "owes": dict(user.get("owes", {})),
            "owed_by": dict(user.get("owed_by", {})),
            "balance": float(user.get("balance", 0.0)),
        }
