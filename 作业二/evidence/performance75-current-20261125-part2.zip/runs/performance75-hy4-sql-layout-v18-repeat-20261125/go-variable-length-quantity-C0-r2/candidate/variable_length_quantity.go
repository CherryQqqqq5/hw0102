package variablelengthquantity

import "errors"

// EncodeVarint encodes each uint32 as variable length quantities.
// Each byte carries seven bits of the value; all bytes except the last
// one in a value have their high bit set.
func EncodeVarint(input []uint32) []byte {
	output := make([]byte, 0, len(input))
	var buffer [5]byte

	for _, value := range input {
		i := len(buffer)
		for {
			i--
			buffer[i] = byte(value & 0x7f)
			value >>= 7
			if value == 0 {
				break
			}
		}

		for j := i; j < len(buffer)-1; j++ {
			buffer[j] |= 0x80
		}

		output = append(output, buffer[i:]...)
	}

	return output
}

// DecodeVarint decodes a stream of variable length quantities into uint32
// values. It returns an error if a value is unfinished or too large.
func DecodeVarint(input []byte) ([]uint32, error) {
	values := make([]uint32, 0)
	var current uint64
	inProgress := false

	for _, b := range input {
		current = (current << 7) | uint64(b&0x7f)
		inProgress = true

		if current > 0xffffffff {
			return nil, errors.New("VLQ value exceeds 32 bits")
		}

		if b&0x80 == 0 {
			values = append(values, uint32(current))
			current = 0
			inProgress = false
		}
	}

	if inProgress {
		return nil, errors.New("incomplete VLQ sequence")
	}

	return values, nil
}
