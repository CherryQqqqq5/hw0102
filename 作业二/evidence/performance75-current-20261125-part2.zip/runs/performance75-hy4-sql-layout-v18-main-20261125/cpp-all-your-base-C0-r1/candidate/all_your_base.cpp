#include "all_your_base.h"

#include <algorithm>
#include <cstdint>
#include <stdexcept>

namespace all_your_base {

std::vector<unsigned int> convert(
    unsigned int input_base,
    const std::vector<unsigned int>& input_digits,
    unsigned int output_base) {
    if (input_base < 2 || output_base < 2) {
        throw std::invalid_argument("bases must be at least 2");
    }

    for (unsigned int digit : input_digits) {
        if (digit >= input_base) {
            throw std::invalid_argument("digit is not valid in the input base");
        }
    }

    std::size_t first_nonzero = 0;
    while (first_nonzero < input_digits.size() &&
           input_digits[first_nonzero] == 0) {
        ++first_nonzero;
    }

    if (first_nonzero == input_digits.size()) {
        return {};
    }

    std::vector<unsigned int> dividend(
        input_digits.begin() + static_cast<std::ptrdiff_t>(first_nonzero),
        input_digits.end());
    std::vector<unsigned int> output_digits;

    // Repeatedly divide the source-base number by the destination base.
    // Each remainder is one output digit; the quotients form the next
    // dividend.  The 64-bit intermediate cannot overflow because both
    // bases and all digits have unsigned int width.
    while (!dividend.empty()) {
        std::vector<unsigned int> quotient;
        quotient.reserve(dividend.size());
        unsigned int remainder = 0;

        for (unsigned int digit : dividend) {
            const std::uint64_t current =
                static_cast<std::uint64_t>(remainder) * input_base + digit;
            const unsigned int quotient_digit =
                static_cast<unsigned int>(current / output_base);
            remainder = static_cast<unsigned int>(current % output_base);

            if (!quotient.empty() || quotient_digit != 0) {
                quotient.push_back(quotient_digit);
            }
        }

        output_digits.push_back(remainder);
        dividend.swap(quotient);
    }

    std::reverse(output_digits.begin(), output_digits.end());
    return output_digits;
}

}  // namespace all_your_base
