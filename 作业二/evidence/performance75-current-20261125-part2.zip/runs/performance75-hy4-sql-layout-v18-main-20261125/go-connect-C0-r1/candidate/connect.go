package connect

import (
	"fmt"
	"strings"
	"unicode"
)

// ResultOf reports which player has connected the two sides assigned to them.
// It returns an empty string when neither player has made a connection.
//
// A row's leading spaces and the spaces between cells are presentation only.
func ResultOf(lines []string) (string, error) {
	board := make([]string, len(lines))
	width := -1

	for i, line := range lines {
		row := strings.Map(func(r rune) rune {
			if unicode.IsSpace(r) {
				return -1
			}
			return r
		}, line)

		if i == 0 {
			width = len(row)
		} else if len(row) != width {
			return "", fmt.Errorf("row %d has %d cells, want %d", i, len(row), width)
		}

		for j := 0; j < len(row); j++ {
			switch row[j] {
			case '.', 'X', 'O':
			default:
				return "", fmt.Errorf("invalid cell %q at row %d, column %d", row[j], i, j)
			}
		}

		board[i] = row
	}

	if len(board) == 0 || width == 0 {
		return "", nil
	}

	xWins := hasConnection(board, 'X')
	oWins := hasConnection(board, 'O')

	switch {
	case xWins && oWins:
		// This cannot occur on a valid Hex board, but an arbitrary board
		// description must not be reported as a single player's win.
		return "", fmt.Errorf("both players have a winning connection")
	case xWins:
		return "X", nil
	case oWins:
		return "O", nil
	default:
		return "", nil
	}
}

// hasConnection performs a flood fill from the player's starting edge.
// Player X starts on the left and seeks the right edge; player O starts on
// the top and seeks the bottom edge.
func hasConnection(board []string, player byte) bool {
	height := len(board)
	width := len(board[0])

	visited := make([][]bool, height)
	for r := range visited {
		visited[r] = make([]bool, width)
	}

	type cell struct{ row, col int }
	queue := make([]cell, 0, height*width)

	enqueue := func(r, c int) {
		if r < 0 || r >= height || c < 0 || c >= width {
			return
		}
		if visited[r][c] || board[r][c] != player {
			return
		}
		visited[r][c] = true
		queue = append(queue, cell{r, c})
	}

	if player == 'X' {
		for r := 0; r < height; r++ {
			enqueue(r, 0)
		}
	} else {
		for c := 0; c < width; c++ {
			enqueue(0, c)
		}
	}

	for head := 0; head < len(queue); head++ {
		current := queue[head]
		r, c := current.row, current.col

		if (player == 'X' && c == width-1) || (player == 'O' && r == height-1) {
			return true
		}

		// Rows are drawn increasingly indented, so a cell touches two cells
		// in each adjacent row as well as its two horizontal neighbours.
		enqueue(r, c-1)
		enqueue(r, c+1)
		enqueue(r-1, c)
		enqueue(r-1, c+1)
		enqueue(r+1, c-1)
		enqueue(r+1, c)
	}

	return false
}
