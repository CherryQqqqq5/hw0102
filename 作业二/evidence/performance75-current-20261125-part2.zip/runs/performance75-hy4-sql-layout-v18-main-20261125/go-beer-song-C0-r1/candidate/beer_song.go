package beer

import (
	"errors"
	"fmt"
	"strings"
)

const maxBottles = 99

// Song sings the complete song, from 99 bottles down to none.
func Song() string {
	return verses(maxBottles, 0)
}

// Verses sings the inclusive, descending range from start to stop.
func Verses(start, stop int) (string, error) {
	if !validBottleCount(start) || !validBottleCount(stop) {
		return "", errors.New("bottle counts must be between 0 and 99")
	}
	if start < stop {
		return "", errors.New("start must be greater than or equal to stop")
	}

	return verses(start, stop), nil
}

// Verse sings a single verse for n bottles.
func Verse(n int) (string, error) {
	if !validBottleCount(n) {
		return "", errors.New("bottle count must be between 0 and 99")
	}

	return verse(n), nil
}

func validBottleCount(n int) bool {
	return n >= 0 && n <= maxBottles
}

func verses(start, stop int) string {
	var song strings.Builder
	for n := start; n >= stop; n-- {
		song.WriteString(verse(n))
		song.WriteString("\n")
	}
	return song.String()
}

func verse(n int) string {
	switch n {
	case 0:
		return "No more bottles of beer on the wall, no more bottles of beer.\n" +
			"Go to the store and buy some more, 99 bottles of beer on the wall.\n"
	case 1:
		return "1 bottle of beer on the wall, 1 bottle of beer.\n" +
			"Take it down and pass it around, no more bottles of beer on the wall.\n"
	default:
		return fmt.Sprintf(
			"%s of beer on the wall, %s of beer.\n"+
				"Take one down and pass it around, %s of beer on the wall.\n",
			bottles(n), bottles(n), bottles(n-1),
		)
	}
}

func bottles(n int) string {
	switch n {
	case 0:
		return "no more bottles"
	case 1:
		return "1 bottle"
	default:
		return fmt.Sprintf("%d bottles", n)
	}
}
