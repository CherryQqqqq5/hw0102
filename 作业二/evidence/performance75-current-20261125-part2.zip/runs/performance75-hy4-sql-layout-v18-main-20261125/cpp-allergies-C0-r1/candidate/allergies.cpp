#include "allergies.h"

namespace allergies {

namespace {

constexpr unsigned int known_allergen_mask = 255u;

struct Allergen {
    const char *name;
    unsigned int score;
};

constexpr Allergen known_allergens[] = {
    {"eggs", 1u},
    {"peanuts", 2u},
    {"shellfish", 4u},
    {"strawberries", 8u},
    {"tomatoes", 16u},
    {"chocolate", 32u},
    {"pollen", 64u},
    {"cats", 128u},
};

}  // namespace

allergy_test::allergy_test(unsigned int score) : score_(score & known_allergen_mask) {
}

bool allergy_test::is_allergic_to(const std::string &allergen) const {
    for (const Allergen &candidate : known_allergens) {
        if (allergen == candidate.name) {
            return (score_ & candidate.score) != 0u;
        }
    }
    return false;
}

std::unordered_set<std::string> allergy_test::get_allergies() const {
    std::unordered_set<std::string> result;
    for (const Allergen &candidate : known_allergens) {
        if ((score_ & candidate.score) != 0u) {
            result.emplace(candidate.name);
        }
    }
    return result;
}

}  // namespace allergies
