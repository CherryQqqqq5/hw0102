#include "parallel_letter_frequency.h"

#include <algorithm>
#include <array>
#include <cstddef>
#include <thread>
#include <vector>

namespace parallel_letter_frequency {
namespace {

constexpr std::size_t letter_count = 26;
using letter_frequencies = std::array<int, letter_count>;

std::size_t letter_index(char ch)
{
    if (ch >= 'a' && ch <= 'z') {
        return static_cast<std::size_t>(ch - 'a');
    }
    if (ch >= 'A' && ch <= 'Z') {
        return static_cast<std::size_t>(ch - 'A');
    }
    return letter_count;
}

void count_texts(const std::vector<std::string_view>& texts,
                 std::size_t first,
                 std::size_t last,
                 letter_frequencies& counts)
{
    counts.fill(0);

    for (std::size_t i = first; i < last; ++i) {
        for (char ch : texts[i]) {
            const std::size_t index = letter_index(ch);
            if (index != letter_count) {
                ++counts[index];
            }
        }
    }
}

}  // namespace

std::map<char, int> frequency(const std::vector<std::string_view>& texts)
{
    std::map<char, int> result;
    if (texts.empty()) {
        return result;
    }

    unsigned int available_threads = std::thread::hardware_concurrency();
    if (available_threads == 0) {
        available_threads = 1;
    }

    const std::size_t worker_count =
        std::min<std::size_t>(texts.size(), available_threads);
    std::vector<letter_frequencies> partials(worker_count);
    std::vector<std::thread> workers;
    workers.reserve(worker_count);

    for (std::size_t worker = 0; worker < worker_count; ++worker) {
        const std::size_t first = texts.size() * worker / worker_count;
        const std::size_t last = texts.size() * (worker + 1) / worker_count;
        workers.emplace_back(
            [&texts, &partials, worker, first, last]() {
                count_texts(texts, first, last, partials[worker]);
            });
    }

    for (auto& worker : workers) {
        worker.join();
    }

    for (const auto& counts : partials) {
        for (std::size_t i = 0; i < letter_count; ++i) {
            if (counts[i] != 0) {
                result[static_cast<char>('a' + i)] += counts[i];
            }
        }
    }

    return result;
}

}  // namespace parallel_letter_frequency
