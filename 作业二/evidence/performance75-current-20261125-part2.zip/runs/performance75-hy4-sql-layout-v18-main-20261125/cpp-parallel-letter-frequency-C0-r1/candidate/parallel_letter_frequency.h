#if !defined(PARALLEL_LETTER_FREQUENCY_H)
#define PARALLEL_LETTER_FREQUENCY_H

#include <map>
#include <string_view>
#include <vector>

namespace parallel_letter_frequency {

// Returns the number of occurrences of each ASCII letter in `texts`.
// Letter casing is ignored; all other characters are ignored.
std::map<char, int> frequency(const std::vector<std::string_view>& texts);

}  // namespace parallel_letter_frequency

#endif
