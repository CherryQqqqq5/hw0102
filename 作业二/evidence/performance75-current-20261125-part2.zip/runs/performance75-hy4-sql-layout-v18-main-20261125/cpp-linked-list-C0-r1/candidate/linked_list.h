#pragma once

#include <cstddef>
#include <stdexcept>
#include <utility>

namespace linked_list {

template <typename T>
class List {
 private:
  struct Node {
    T value;
    Node* prev;
    Node* next;

    explicit Node(const T& v, Node* p = nullptr, Node* n = nullptr)
        : value(v), prev(p), next(n) {}

    explicit Node(T&& v, Node* p = nullptr, Node* n = nullptr)
        : value(std::move(v)), prev(p), next(n) {}
  };

  Node* head_ = nullptr;
  Node* tail_ = nullptr;
  std::size_t count_ = 0;

  void clear() noexcept {
    Node* current = head_;
    while (current != nullptr) {
      Node* next = current->next;
      delete current;
      current = next;
    }
    head_ = nullptr;
    tail_ = nullptr;
    count_ = 0;
  }

 public:
  List() = default;

  ~List() { clear(); }

  List(const List& other) {
    for (Node* current = other.head_; current != nullptr;
         current = current->next) {
      push(current->value);
    }
  }

  List(List&& other) noexcept
      : head_(other.head_), tail_(other.tail_), count_(other.count_) {
    other.head_ = nullptr;
    other.tail_ = nullptr;
    other.count_ = 0;
  }

  List& operator=(const List& other) {
    if (this != &other) {
      List copy(other);
      swap(copy);
    }
    return *this;
  }

  List& operator=(List&& other) noexcept {
    if (this != &other) {
      clear();
      head_ = other.head_;
      tail_ = other.tail_;
      count_ = other.count_;
      other.head_ = nullptr;
      other.tail_ = nullptr;
      other.count_ = 0;
    }
    return *this;
  }

  void swap(List& other) noexcept {
    using std::swap;
    swap(head_, other.head_);
    swap(tail_, other.tail_);
    swap(count_, other.count_);
  }

  void push(const T& value) {
    Node* node = new Node(value, tail_, nullptr);
    if (tail_ != nullptr) {
      tail_->next = node;
    } else {
      head_ = node;
    }
    tail_ = node;
    ++count_;
  }

  void push(T&& value) {
    Node* node = new Node(std::move(value), tail_, nullptr);
    if (tail_ != nullptr) {
      tail_->next = node;
    } else {
      head_ = node;
    }
    tail_ = node;
    ++count_;
  }

  T pop() {
    if (head_ == nullptr) {
      throw std::out_of_range("cannot pop from an empty list");
    }

    T value = std::move(tail_->value);
    Node* old_tail = tail_;
    tail_ = old_tail->prev;
    if (tail_ != nullptr) {
      tail_->next = nullptr;
    } else {
      head_ = nullptr;
    }
    delete old_tail;
    --count_;
    return value;
  }

  void unshift(const T& value) {
    Node* node = new Node(value, nullptr, head_);
    if (head_ != nullptr) {
      head_->prev = node;
    } else {
      tail_ = node;
    }
    head_ = node;
    ++count_;
  }

  void unshift(T&& value) {
    Node* node = new Node(std::move(value), nullptr, head_);
    if (head_ != nullptr) {
      head_->prev = node;
    } else {
      tail_ = node;
    }
    head_ = node;
    ++count_;
  }

  T shift() {
    if (head_ == nullptr) {
      throw std::out_of_range("cannot shift from an empty list");
    }

    T value = std::move(head_->value);
    Node* old_head = head_;
    head_ = old_head->next;
    if (head_ != nullptr) {
      head_->prev = nullptr;
    } else {
      tail_ = nullptr;
    }
    delete old_head;
    --count_;
    return value;
  }

  std::size_t count() const noexcept { return count_; }

  bool erase(const T& value) {
    for (Node* current = head_; current != nullptr; current = current->next) {
      if (current->value == value) {
        if (current->prev != nullptr) {
          current->prev->next = current->next;
        } else {
          head_ = current->next;
        }

        if (current->next != nullptr) {
          current->next->prev = current->prev;
        } else {
          tail_ = current->prev;
        }

        delete current;
        --count_;
        return true;
      }
    }
    return false;
  }
};

}  // namespace linked_list
