package variablelengthquantity

import "errors"

const (
	continuationBit byte = 0x80
	valueMask       byte = 0x7f
)

// EncodeVarint encodes each uint32 as a variable-length quantity.
func EncodeVarint(input []uint32) []byte {
	output := make([]byte, 0, len(input))

	for _, value := range input {
		// Collect the seven-bit groups least-significant first.
		groups := []byte{byte(value & uint32(valueMask))}
		for value > uint32(valueMask) {
			value >>= 7
			groups = append(groups, byte(value&uint32(valueMask)))
		}

		// VLQ writes the groups most-significant first. All but the last
		// byte have the continuation bit set.
		for i := len(groups) - 1; i > 0; i-- {
			output = append(output, groups[i]|continuationBit)
		}
		output = append(output, groups[0])
	}

	return output
}

// DecodeVarint decodes a stream of variable-length quantities into uint32 values.
func DecodeVarint(input []byte) ([]uint32, error) {
	values := make([]uint32, 0, len(input))

	var value uint64
	var bytesInValue uint

	for _, b := range input {
		// A uint32 needs at most five bytes: four groups of seven bits plus
		// the four remaining high bits.
		if bytesInValue == 5 {
			return nil, errors.New("variable length quantity exceeds 32 bits")
		}

		value = value<<7 | uint64(b&valueMask)
		bytesInValue++

		if b&continuationBit != 0 {
			continue
		}

		if value > uint64(^uint32(0)) {
			return nil, errors.New("variable length quantity exceeds 32 bits")
		}

		values = append(values, uint32(value))
		value = 0
		bytesInValue = 0
	}

	if bytesInValue != 0 {
		return nil, errors.New("incomplete variable length quantity")
	}

	return values, nil
}
