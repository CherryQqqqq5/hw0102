package trinary

import "errors"

func ParseTrinary(arg string) (int64, error) {
	if len(arg) == 0 {
		return 0, errors.New("invalid trinary")
	}

	const maxInt64 = int64(1<<63 - 1)
	var value int64
	for i := 0; i < len(arg); i++ {
		digit := arg[i]
		if digit < '0' || digit > '2' {
			return 0, errors.New("invalid trinary")
		}

		d := int64(digit - '0')
		if value > (maxInt64-d)/3 {
			return 0, errors.New("trinary overflow")
		}
		value = value*3 + d
	}

	return value, nil
}
