class PhoneNumber {

    private final String number;

    PhoneNumber(String numberString) {
        if (numberString == null) {
            throw new IllegalArgumentException("must not be fewer than 10 digits");
        }

        for (int i = 0; i < numberString.length(); i++) {
            char character = numberString.charAt(i);
            if (Character.isLetter(character)) {
                throw new IllegalArgumentException("letters not permitted");
            }
            if (!Character.isDigit(character)
                    && character != ' '
                    && character != '('
                    && character != ')'
                    && character != '-'
                    && character != '.'
                    && character != '+') {
                throw new IllegalArgumentException("punctuations not permitted");
            }
        }

        String digits = numberString.replaceAll("\\D", "");

        if (digits.length() < 10) {
            throw new IllegalArgumentException("must not be fewer than 10 digits");
        }
        if (digits.length() > 11) {
            throw new IllegalArgumentException("must not be greater than 11 digits");
        }

        if (digits.length() == 11) {
            if (digits.charAt(0) != '1') {
                throw new IllegalArgumentException("11 digits must start with 1");
            }
            digits = digits.substring(1);
        }

        if (digits.charAt(0) == '0') {
            throw new IllegalArgumentException("area code cannot start with zero");
        }
        if (digits.charAt(0) == '1') {
            throw new IllegalArgumentException("area code cannot start with one");
        }
        if (digits.charAt(3) == '0') {
            throw new IllegalArgumentException("exchange code cannot start with zero");
        }
        if (digits.charAt(3) == '1') {
            throw new IllegalArgumentException("exchange code cannot start with one");
        }

        this.number = digits;
    }

    String getNumber() {
        return number;
    }
}
