#!/usr/bin/env python3
"""Extract the first-layer ReLU directions from the scalar oracle in forward.py."""
import importlib.util
from pathlib import Path

import numpy as np

APP_DIR = Path(__file__).resolve().parent
ORACLE_PATH = APP_DIR / "forward.py"
HELPER_PATH = Path("/opt/course-tools/relu_recovery.py")
OUTPUT_PATH = APP_DIR / "stolen_A1.npy"


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load module from {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> None:
    victim = load_module("victim_forward", ORACLE_PATH)
    oracle = getattr(victim, "forward")
    recovery = load_module("relu_recovery", HELPER_PATH)

    rows, diagnostics = recovery.recover_relu_directions(
        oracle,
        dimension=10,
        n_lines=23,
        seed=39117,
    )
    np.save(OUTPUT_PATH, rows)

    print(f"saved {OUTPUT_PATH} with shape {rows.shape}")
    print(f"oracle queries: {diagnostics['oracle_queries']}")
    print(f"recovered directions: {diagnostics['recovered_directions']}")


if __name__ == "__main__":
    main()
