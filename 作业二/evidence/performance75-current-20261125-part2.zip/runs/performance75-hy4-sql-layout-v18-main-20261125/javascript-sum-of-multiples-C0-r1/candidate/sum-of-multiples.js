export const sum = (factors, limit) => {
  const multiples = new Set();

  for (const factor of factors) {
    const step = Math.abs(factor);

    if (step === 0) {
      continue;
    }

    for (let multiple = step; multiple < limit; multiple += step) {
      multiples.add(multiple);
    }
  }

  let total = 0;
  for (const multiple of multiples) {
    total += multiple;
  }

  return total;
};
