export class Triangle {
  constructor(...sides) {
    this.sides = sides;
  }

  get isValid() {
    if (this.sides.length !== 3) {
      return false;
    }

    const [a, b, c] = this.sides;

    if ([a, b, c].some((side) => !Number.isFinite(side) || side <= 0)) {
      return false;
    }

    return a + b >= c && b + c >= a && a + c >= b;
  }

  get isEquilateral() {
    if (!this.isValid) {
      return false;
    }

    const [a, b, c] = this.sides;
    return a === b && b === c;
  }

  get isIsosceles() {
    if (!this.isValid) {
      return false;
    }

    const [a, b, c] = this.sides;
    return a === b || a === c || b === c;
  }

  get isScalene() {
    if (!this.isValid) {
      return false;
    }

    const [a, b, c] = this.sides;
    return a !== b && a !== c && b !== c;
  }
}
