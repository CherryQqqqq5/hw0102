const animals = [
  { name: 'fly' },
  {
    name: 'spider',
    line: 'It wriggled and jiggled and tickled inside her.',
    catchPhrase: 'that wriggled and jiggled and tickled inside her',
  },
  { name: 'bird', line: 'How absurd to swallow a bird!' },
  { name: 'cat', line: 'Imagine that, to swallow a cat!' },
  { name: 'dog', line: 'What a hog, to swallow a dog!' },
  { name: 'goat', line: 'Just opened her throat and swallowed a goat!' },
  { name: 'cow', line: "I don't know how she swallowed a cow!" },
  { name: 'horse', line: "She's dead, of course!" },
];

export class Song {
  verse(number) {
    const index = number - 1;
    const animal = animals[index];

    const lines = [`I know an old lady who swallowed a ${animal.name}.`];

    if (number === animals.length) {
      lines.push(animal.line);
      return `${lines.join('\n')}\n`;
    }

    if (animal.line) {
      lines.push(animal.line);
    }

    for (let currentIndex = index; currentIndex > 0; currentIndex -= 1) {
      const current = animals[currentIndex];
      const caught = animals[currentIndex - 1];
      const catchPhrase = caught.catchPhrase ? ` ${caught.catchPhrase}` : '';

      lines.push(
        `She swallowed the ${current.name} to catch the ${caught.name}${catchPhrase}.`,
      );
    }

    lines.push("I don't know why she swallowed the fly. Perhaps she'll die.");

    return `${lines.join('\n')}\n`;
  }

  verses(first, last) {
    let song = '';

    for (let number = first; number <= last; number += 1) {
      song += `${this.verse(number)}\n`;
    }

    return song;
  }
}
