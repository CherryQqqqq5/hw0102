#!/usr/bin/env node
'use strict';

const fs = require('fs');

function fail(message) {
  process.stderr.write(`extract.js: ${message}\n`);
  process.exit(1);
}

function main() {
  const filename = process.argv[2];
  if (!filename) fail('usage: node extract.js <binary>');

  const buf = fs.readFileSync(filename);
  if (buf.length < 52 || buf.toString('ascii', 0, 4) !== '\x7fELF') {
    fail('not an ELF file');
  }

  const elfClass = buf[4]; // 1 = ELF32, 2 = ELF64
  const encoding = buf[5]; // 1 = little endian, 2 = big endian
  if (elfClass !== 1 && elfClass !== 2) fail('unsupported ELF class');
  if (encoding !== 1 && encoding !== 2) fail('unsupported ELF byte order');
  const le = encoding === 1;

  const u16 = (off) => le ? buf.readUInt16LE(off) : buf.readUInt16BE(off);
  const u32 = (off) => le ? buf.readUInt32LE(off) : buf.readUInt32BE(off);
  const u64 = (off) => {
    if (off + 8 > buf.length) fail('truncated ELF header');
    return le ? buf.readBigUInt64LE(off) : buf.readBigUInt64BE(off);
  };

  let phoff, phentsize, phnum;
  if (elfClass === 2) {
    if (buf.length < 64) fail('truncated ELF64 header');
    phoff = u64(32);
    phentsize = u16(54);
    phnum = u16(56);
  } else {
    if (buf.length < 52) fail('truncated ELF32 header');
    phoff = BigInt(u32(28));
    phentsize = u16(42);
    phnum = u16(44);
  }

  // Extended program header count (PN_XNUM): real count is in section 0's sh_info.
  if (phnum === 0xffff) {
    const shoff = elfClass === 2 ? u64(40) : BigInt(u32(32));
    if (elfClass === 2) {
      if (shoff + 64n > BigInt(buf.length)) fail('truncated section header table');
      phnum = u16(Number(shoff) + 44);
    } else {
      if (shoff + 40n > BigInt(buf.length)) fail('truncated section header table');
      phnum = u32(Number(shoff) + 28);
    }
  }

  if (phentsize === 0) fail('no program headers');
  const out = Object.create(null);

  for (let i = 0; i < phnum; i++) {
    const ph = phoff + BigInt(i) * BigInt(phentsize);
    if (ph < 0n || ph + BigInt(phentsize) > BigInt(buf.length)) {
      fail('program header table extends past end of file');
    }
    const base = Number(ph);
    if (u32(base) !== 1) continue; // PT_LOAD

    let off, vaddr, filesz, memsz;
    if (elfClass === 2) {
      off = Number(u64(base + 8));
      vaddr = u64(base + 16);
      filesz = u64(base + 32);
      memsz = u64(base + 40);
    } else {
      off = u32(base + 4);
      vaddr = BigInt(u32(base + 8));
      filesz = BigInt(u32(base + 16));
      memsz = BigInt(u32(base + 20));
    }

    // segment.data() exposes the file-backed bytes; memory beyond that is zero.
    const available = off <= buf.length ? Math.min(Number(filesz), buf.length - off) : 0;
    for (let delta = 0n; delta + 4n <= memsz; delta += 4n) {
      const d = Number(delta);
      let value = 0;
      for (let b = 0; b < 4; b++) {
        const byte = d + b < available ? buf[off + d + b] : 0;
        if (le) value += byte << (8 * b);
        else value = (value << 8) | byte;
      }
      out[(vaddr + delta).toString()] = value >>> 0;
    }
  }

  process.stdout.write(JSON.stringify(out));
}

main();
