/* /*
; // */
#if 0
*/
use std::env;

fn add_dec(a: &str, b: &str) -> String {
    let ba = a.as_bytes();
    let bb = b.as_bytes();
    let mut out = Vec::with_capacity(ba.len().max(bb.len()) + 1);
    let mut carry = 0u8;
    let mut i = ba.len();
    let mut j = bb.len();
    while i > 0 || j > 0 || carry > 0 {
        let da = if i > 0 { i -= 1; ba[i] - b'0' } else { 0 };
        let db = if j > 0 { j -= 1; bb[j] - b'0' } else { 0 };
        let s = da + db + carry;
        out.push(b'0' + (s % 10));
        carry = s / 10;
    }
    out.reverse();
    String::from_utf8(out).unwrap()
}

fn main() {
    let n: u64 = env::args().nth(1).unwrap().parse().unwrap();
    if n <= 1 {
        println!("1");
        return;
    }
    let mut a = String::from("1");
    let mut b = String::from("1");
    for _ in 2..=n {
        let c = add_dec(&a, &b);
        a = b;
        b = c;
    }
    println!("{}", b);
}
/* /*
; // */
#endif
#include <iostream>
#include <string>
#include <algorithm>

std::string add_dec(const std::string& a, const std::string& b) {
    std::string out;
    size_t i = a.size(), j = b.size();
    int carry = 0;
    out.reserve(std::max(a.size(), b.size()) + 1);
    while (i > 0 || j > 0 || carry > 0) {
        int da = (i > 0) ? a[--i] - '0' : 0;
        int db = (j > 0) ? b[--j] - '0' : 0;
        int s = da + db + carry;
        out.push_back(static_cast<char>('0' + s % 10));
        carry = s / 10;
    }
    std::reverse(out.begin(), out.end());
    return out;
}

int main(int argc, char** argv) {
    unsigned long long n = std::stoull(argv[1]);
    if (n <= 1) {
        std::cout << 1 << '\n';
        return 0;
    }
    std::string a = "1", b = "1";
    for (unsigned long long k = 2; k <= n; ++k) {
        std::string c = add_dec(a, b);
        a = b;
        b = c;
    }
    std::cout << b << '\n';
    return 0;
}
; // */
