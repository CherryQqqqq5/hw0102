const SUBJECTS = [
  'the house that Jack built.',
  'the malt',
  'the rat',
  'the cat',
  'the dog',
  'the cow with the crumpled horn',
  'the maiden all forlorn',
  'the man all tattered and torn',
  'the priest all shaven and shorn',
  'the rooster that crowed in the morn',
  'the farmer sowing his corn',
  'the horse and the hound and the horn',
];

const ACTIONS = [
  null,
  'that lay in',
  'that ate',
  'that killed',
  'that worried',
  'that tossed',
  'that milked',
  'that kissed',
  'that married',
  'that woke',
  'that kept',
  'that belonged to',
];

export class House {
  static verse(verseNumber) {
    const lyrics = [`This is ${SUBJECTS[verseNumber - 1]}`];

    for (let subjectIndex = verseNumber - 1; subjectIndex > 0; subjectIndex -= 1) {
      lyrics.push(`${ACTIONS[subjectIndex]} ${SUBJECTS[subjectIndex - 1]}`);
    }

    return lyrics;
  }

  static verses(startVerse, endVerse) {
    const lyrics = [];

    for (let verseNumber = startVerse; verseNumber <= endVerse; verseNumber += 1) {
      if (lyrics.length > 0) {
        lyrics.push('');
      }

      lyrics.push(...House.verse(verseNumber));
    }

    return lyrics;
  }
}
