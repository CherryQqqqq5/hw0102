class PigLatinTranslator {
    public String translate(String text) {
        if (text == null) {
            return null;
        }

        String trimmed = text.trim();
        if (trimmed.isEmpty()) {
            return "";
        }

        String[] words = trimmed.split("\\s+");
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < words.length; i++) {
            if (i > 0) {
                result.append(' ');
            }
            result.append(translateWord(words[i]));
        }

        return result.toString();
    }

    private String translateWord(String word) {
        if (word.startsWith("xr") || word.startsWith("yt") || isVowel(word.charAt(0))) {
            return word + "ay";
        }

        int firstVowel = findFirstVowelIndex(word);
        String consonants = word.substring(0, firstVowel);
        String rest = word.substring(firstVowel);
        return rest + consonants + "ay";
    }

    private int findFirstVowelIndex(String word) {
        for (int i = 0; i < word.length(); i++) {
            char current = word.charAt(i);

            if (current == 'q' && i + 1 < word.length() && word.charAt(i + 1) == 'u') {
                i++;
                continue;
            }

            if (isVowel(current) || (current == 'y' && i > 0)) {
                return i;
            }
        }

        return word.length();
    }

    private boolean isVowel(char c) {
        return c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u';
    }
}
