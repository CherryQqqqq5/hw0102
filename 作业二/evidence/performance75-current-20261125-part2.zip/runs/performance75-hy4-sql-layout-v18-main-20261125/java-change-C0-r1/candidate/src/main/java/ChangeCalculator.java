import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

class ChangeCalculator {
    private final List<Integer> currencyCoins;

    ChangeCalculator(List<Integer> currencyCoins) {
        TreeSet<Integer> distinctCoins = new TreeSet<>();
        if (currencyCoins != null) {
            for (Integer coin : currencyCoins) {
                if (coin != null && coin > 0) {
                    distinctCoins.add(coin);
                }
            }
        }
        this.currencyCoins = new ArrayList<>(distinctCoins);
    }

    List<Integer> computeMostEfficientChange(int grandTotal) {
        if (grandTotal < 0) {
            throw new IllegalArgumentException("Negative totals are not allowed.");
        }
        if (grandTotal == 0) {
            return new ArrayList<>();
        }

        int unreachable = grandTotal + 1;
        int[] minimumCoins = new int[grandTotal + 1];
        int[] previousAmount = new int[grandTotal + 1];
        int[] coinUsed = new int[grandTotal + 1];

        for (int amount = 1; amount <= grandTotal; amount++) {
            minimumCoins[amount] = unreachable;

            for (int coin : currencyCoins) {
                if (coin > amount) {
                    break;
                }

                int remainder = amount - coin;
                if (minimumCoins[remainder] == unreachable) {
                    continue;
                }

                int candidateCount = minimumCoins[remainder] + 1;
                if (candidateCount < minimumCoins[amount]) {
                    minimumCoins[amount] = candidateCount;
                    previousAmount[amount] = remainder;
                    coinUsed[amount] = coin;
                }
            }
        }

        if (minimumCoins[grandTotal] == unreachable) {
            throw new IllegalArgumentException(
                    "The total " + grandTotal + " cannot be represented in the given currency.");
        }

        List<Integer> change = new ArrayList<>(minimumCoins[grandTotal]);
        for (int amount = grandTotal; amount > 0; amount = previousAmount[amount]) {
            change.add(coinUsed[amount]);
        }
        return change;
    }
}
