package alphametics

import (
	"errors"
	"sort"
	"strings"
)

var errNoSolution = errors.New("no solution")

type puzzleData struct {
	addends [][]int
	result  []int
	letters []byte
	leading []bool
	coeffs  [][]int // signed coefficient of every letter in each column
	columns [][]int // letters occurring in each column
	width   int
}

func parsePuzzle(puzzle string) (*puzzleData, error) {
	compact := strings.Join(strings.Fields(puzzle), "")
	parts := strings.Split(compact, "==")
	if len(parts) != 2 {
		return nil, errNoSolution
	}

	addendWords := strings.Split(parts[0], "+")
	if len(addendWords) == 0 || addendWords[0] == "" {
		return nil, errNoSolution
	}
	resultWord := parts[1]
	if resultWord == "" {
		return nil, errNoSolution
	}

	index := make(map[byte]int)
	var letters []byte
	addWord := func(word string) error {
		if word == "" {
			return errNoSolution
		}
		for i := 0; i < len(word); i++ {
			c := word[i]
			if c < 'A' || c > 'Z' {
				return errNoSolution
			}
			if _, ok := index[c]; !ok {
				index[c] = len(letters)
				letters = append(letters, c)
			}
		}
		return nil
	}

	for _, word := range addendWords {
		if err := addWord(word); err != nil {
			return nil, err
		}
	}
	if err := addWord(resultWord); err != nil {
		return nil, err
	}
	if len(letters) > 10 {
		return nil, errNoSolution
	}

	p := &puzzleData{
		letters: letters,
		leading: make([]bool, len(letters)),
	}
	markLeading := func(word string) {
		if len(word) > 1 {
			p.leading[index[word[0]]] = true
		}
	}
	for _, word := range addendWords {
		markLeading(word)
	}
	markLeading(resultWord)

	toIndices := func(word string) []int {
		wordIndices := make([]int, len(word))
		for i := 0; i < len(word); i++ {
			wordIndices[i] = index[word[i]]
		}
		return wordIndices
	}
	for _, word := range addendWords {
		p.addends = append(p.addends, toIndices(word))
	}
	p.result = toIndices(resultWord)

	for _, word := range p.addends {
		if len(word) > p.width {
			p.width = len(word)
		}
	}
	if len(p.result) > p.width {
		p.width = len(p.result)
	}
	p.coeffs = make([][]int, p.width)
	p.columns = make([][]int, p.width)
	for col := 0; col < p.width; col++ {
		p.coeffs[col] = make([]int, len(letters))
		p.columns[col] = []int{}
	}

	addContribution := func(col, letter, delta int) {
		p.coeffs[col][letter] += delta
		for _, existing := range p.columns[col] {
			if existing == letter {
				return
			}
		}
		p.columns[col] = append(p.columns[col], letter)
	}
	for _, word := range p.addends {
		for pos, letter := range word {
			addContribution(len(word)-1-pos, letter, 1)
		}
	}
	for pos, letter := range p.result {
		addContribution(len(p.result)-1-pos, letter, -1)
	}

	return p, nil
}

// Solve finds an injective digit assignment that makes puzzle true.
func Solve(puzzle string) (map[string]int, error) {
	p, err := parsePuzzle(puzzle)
	if err != nil {
		return nil, err
	}

	n := len(p.letters)
	if n > 10 {
		return nil, errNoSolution
	}
	// With all ten digits in use, zero must belong to a letter that is
	// allowed to be leading; otherwise no assignment can exist.
	if n == 10 {
		zeroAllowed := false
		for _, leading := range p.leading {
			if !leading {
				zeroAllowed = true
				break
			}
		}
		if !zeroAllowed {
			return nil, errNoSolution
		}
	}

	// Assign the most constrained letters first. Letters that cannot lead
	// come first so that the zero digit is tried in the right place.
	order := make([]int, n)
	for i := range order {
		order[i] = i
	}
	weight := make([]int, n)
	for col := range p.coeffs {
		for letter, coeff := range p.coeffs[col] {
			if coeff < 0 {
				weight[letter] -= coeff
			} else {
				weight[letter] += coeff
			}
		}
	}
	sort.SliceStable(order, func(i, j int) bool {
		a, b := order[i], order[j]
		if p.leading[a] != p.leading[b] {
			return !p.leading[a]
		}
		return weight[a] > weight[b]
	})

	assignment := make([]int, n)
	assigned := make([]bool, n)
	usedDigit := make([]bool, 10)

	valid := func() bool {
		carry := 0
		for col := 0; col < p.width; col++ {
			ready := true
			for _, letter := range p.columns[col] {
				if !assigned[letter] {
					ready = false
					break
				}
			}
			if !ready {
				return true
			}
			sum := carry
			for letter, coeff := range p.coeffs[col] {
				sum += coeff * assignment[letter]
			}
			if sum < 0 || sum%10 != 0 {
				return false
			}
			carry = sum / 10
		}
		return carry == 0
	}

	var search func(depth int) bool
	search = func(depth int) bool {
		if depth == n {
			return true
		}
		letter := order[depth]
		for digit := 0; digit <= 9; digit++ {
			if usedDigit[digit] || (digit == 0 && p.leading[letter]) {
				continue
			}
			assignment[letter] = digit
			assigned[letter] = true
			usedDigit[digit] = true
			if valid() && search(depth+1) {
				return true
			}
			usedDigit[digit] = false
			assigned[letter] = false
			assignment[letter] = 0
		}
		return false
	}

	if !search(0) {
		return nil, errNoSolution
	}

	solution := make(map[string]int, n)
	for i, letter := range p.letters {
		solution[string(letter)] = assignment[i]
	}
	return solution, nil
}
