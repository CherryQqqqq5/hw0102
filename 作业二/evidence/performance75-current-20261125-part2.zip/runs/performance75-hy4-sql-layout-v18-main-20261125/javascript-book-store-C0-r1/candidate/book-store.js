/*
 * A group can contain at most one copy of each title.  If a basket has n
 * books and is split into g groups, the groups have 5g slots; 5g - n of
 * those slots are empty.  Let m[h] be the number of groups with h empty
 * slots, so a group with h empty slots contains 5 - h books.
 *
 * For sorted title counts a >= b >= c >= d >= e, the matrix of empty slots
 * must be realisable.  Gale-Ryser's conditions reduce here to:
 *
 *   m[4] <= 2g - a - b
 *   m[3] + 2*m[4] <= 3g - a - b - c
 *
 * Together with m[0] + ... + m[4] = g and
 * m[1] + 2*m[2] + 3*m[3] + 4*m[4] = 5g - n, these conditions allow the
 * cheapest grouping to be found algebraically for each possible g.
 */
export const cost = (books) => {
  const counts = [0, 0, 0, 0, 0];
  for (const book of books) {
    counts[book - 1] += 1;
  }

  counts.sort((left, right) => right - left);
  const [a, b, c] = counts;
  const total = books.length;

  if (total === 0) {
    return 0;
  }

  let cheapest = Infinity;

  for (let groups = a; groups <= total; groups += 1) {
    const emptySlots = 5 * groups - total;
    const adjustedEmpties = 4 * groups - total;
    const maxSizeThreeGroups = 3 * groups - a - b - c;
    const maxSizeOneGroups = Math.min(
      2 * groups - a - b,
      Math.floor(emptySlots / 4),
    );

    let bestScore = -Infinity;

    for (let sizeOneGroups = 0; sizeOneGroups <= maxSizeOneGroups; sizeOneGroups += 1) {
      /*
       * Two possible shapes remain after choosing the number of singleton
       * groups.  Either there are no complete groups (m[0] = 0), in which
       * case some groups must be threes/twos to absorb the empties, or there
       * are complete groups and no threes (otherwise a five plus a three
       * could always be rearranged into two cheaper fours).
       */
      let low = Math.max(0, 3 * groups - total - 2 * sizeOneGroups);
      let high = Math.min(
        maxSizeThreeGroups - 2 * sizeOneGroups,
        Math.floor((adjustedEmpties - 3 * sizeOneGroups) / 2),
      );

      if (low <= high) {
        bestScore = Math.max(bestScore, 6 * high + 14 * sizeOneGroups);
      }

      low = Math.max(
        0,
        Math.floor((adjustedEmpties - 3 * sizeOneGroups) / 2) + 1,
      );
      high = Math.min(
        maxSizeThreeGroups - 2 * sizeOneGroups,
        Math.floor((emptySlots - 4 * sizeOneGroups) / 3),
      );

      if (low <= high) {
        bestScore = Math.max(
          bestScore,
          adjustedEmpties + 4 * high + 11 * sizeOneGroups,
        );
      }
    }

    if (bestScore !== -Infinity) {
      const groupCost = 440 * total + 800 * groups
        + 40 * adjustedEmpties - 40 * bestScore;
      cheapest = Math.min(cheapest, groupCost);
    }
  }

  return cheapest;
};

