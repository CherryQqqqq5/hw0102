#!/usr/bin/env python3
"""Verify that the generated TLS certificate exists and can be loaded."""

from __future__ import annotations

import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path

CERT_PATH = Path(__file__).resolve().parent / "ssl" / "server.crt"


def run_openssl(*args: str) -> str:
    """Run openssl x509 against CERT_PATH and return stdout."""
    try:
        result = subprocess.run(
            ["openssl", "x509", "-in", str(CERT_PATH), "-noout", *args],
            check=True,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError as exc:
        raise RuntimeError("openssl is not installed or not on PATH") from exc
    except subprocess.CalledProcessError as exc:
        message = exc.stderr.strip() or "could not load certificate"
        raise RuntimeError(message) from exc
    return result.stdout.strip()


def parse_expiration(enddate_line: str) -> datetime:
    value = enddate_line.split("=", 1)[1] if "=" in enddate_line else enddate_line
    for fmt in ("%b %d %H:%M:%S %Y %Z", "%b %d %H:%M:%S %Y"):
        try:
            return datetime.strptime(value.strip(), fmt)
        except ValueError:
            continue
    raise RuntimeError(f"unrecognized expiration date: {value!r}")


def main() -> int:
    if not CERT_PATH.exists():
        raise RuntimeError(f"certificate file not found: {CERT_PATH}")
    if not CERT_PATH.is_file():
        raise RuntimeError(f"certificate path is not a regular file: {CERT_PATH}")

    # This both parses the certificate and fails if it has already expired.
    run_openssl("-checkend", "0")

    subject_line = run_openssl("-subject", "-nameopt", "RFC2253")
    subject = subject_line.split("=", 1)[1] if subject_line.startswith("subject=") else subject_line
    common_name_match = re.search(r"(?:^|,)CN=([^,]+)", subject)
    if not common_name_match:
        raise RuntimeError("Common Name not found in certificate subject")
    common_name = common_name_match.group(1)

    expiration = parse_expiration(run_openssl("-enddate"))

    print("Certificate details:")
    print(f"Common Name: {common_name}")
    print(f"Expiration Date: {expiration.strftime('%Y-%m-%d')}")
    print("Certificate verification successful")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print(f"Certificate verification failed: {exc}", file=sys.stderr)
        sys.exit(1)
