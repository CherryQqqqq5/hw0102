#!/usr/bin/env python3
"""Modernized Python 3 climate analysis script."""

from __future__ import annotations

import argparse
import configparser
from pathlib import Path

import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
DEFAULT_CSV_PATH = (
    BASE_DIR / "climate_analyzer" / "sample_data" / "climate_data.csv"
)
DEFAULT_CONFIG_PATH = BASE_DIR / "climate_analyzer" / "config.ini"


def parse_args() -> argparse.Namespace:
    """Parse optional data/config paths, defaulting to the bundled files."""
    parser = argparse.ArgumentParser(description="Calculate mean temperature by station.")
    parser.add_argument(
        "--csv",
        type=Path,
        default=DEFAULT_CSV_PATH,
        help="Path to the climate CSV file.",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=DEFAULT_CONFIG_PATH,
        help="Path to the climate configuration file.",
    )
    return parser.parse_args()


def load_config(config_path: Path) -> configparser.ConfigParser:
    """Read the configuration with the Python 3 configparser implementation."""
    config = configparser.ConfigParser()
    config.read(config_path, encoding="utf-8")
    return config


def load_temperature_data(csv_path: Path) -> pd.DataFrame:
    """Load climate observations from a UTF-8 encoded CSV."""
    return pd.read_csv(csv_path, encoding="utf-8")


def format_station_id(station_id: object) -> str:
    """Render numeric station identifiers without a spurious trailing .0."""
    if isinstance(station_id, float) and station_id.is_integer():
        return str(int(station_id))
    return str(station_id)


def main() -> None:
    args = parse_args()

    # Read the modernized config even though the mean calculation needs no settings;
    # this keeps configuration available for future analysis options.
    load_config(args.config)

    data = load_temperature_data(args.csv)
    required_columns = {"station_id", "temperature"}
    missing_columns = required_columns.difference(data.columns)
    if missing_columns:
        missing = ", ".join(sorted(missing_columns))
        raise ValueError(f"Missing required CSV column(s): {missing}")

    data = data.assign(temperature=pd.to_numeric(data["temperature"]))
    for station_id, group in data.groupby("station_id", sort=True):
        mean_temperature = group["temperature"].mean()
        print(
            f"Station {format_station_id(station_id)} mean temperature: "
            f"{mean_temperature:.1f}°C"
        )


if __name__ == "__main__":
    main()
