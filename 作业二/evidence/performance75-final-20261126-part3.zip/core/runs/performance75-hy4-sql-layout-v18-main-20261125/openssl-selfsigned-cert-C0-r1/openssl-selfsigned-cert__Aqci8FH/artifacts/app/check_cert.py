#!/usr/bin/env python3
"""Verify the internal development TLS certificate and print key details."""

import os
import re
import subprocess
import sys
from datetime import date

CERT_PATH = "/app/ssl/server.crt"


def openssl(*args: str) -> str:
    """Run an OpenSSL command and return stdout, or raise on failure."""
    result = subprocess.run(
        ["openssl", *args],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "OpenSSL command failed")
    return result.stdout.strip()


def parse_openssl_date(value: str) -> str:
    """Convert an OpenSSL -enddate/-startdate value to YYYY-MM-DD."""
    parts = " ".join(value.split()).split()
    months = {
        "Jan": 1, "Feb": 2, "Mar": 3, "Apr": 4, "May": 5, "Jun": 6,
        "Jul": 7, "Aug": 8, "Sep": 9, "Oct": 10, "Nov": 11, "Dec": 12,
    }
    if len(parts) < 4 or parts[0] not in months:
        raise ValueError(f"Unrecognized certificate date: {value}")
    return date(int(parts[3]), months[parts[0]], int(parts[1])).isoformat()


def main() -> int:
    try:
        if not os.path.isfile(CERT_PATH):
            raise FileNotFoundError(f"Certificate not found: {CERT_PATH}")

        # A successful parse of the full certificate text proves it can be loaded.
        openssl("x509", "-in", CERT_PATH, "-noout", "-text")

        subject = openssl("x509", "-in", CERT_PATH, "-noout", "-subject")
        subject = subject.split("=", 1)[1].strip()
        enddate = openssl("x509", "-in", CERT_PATH, "-noout", "-enddate")
        enddate = enddate.split("=", 1)[1].strip()

        cn_match = re.search(r"(?:^|[,/])\s*CN\s*=\s*([^,/]+)", subject)
        if not cn_match:
            raise ValueError("Common Name not found in certificate subject")
        common_name = cn_match.group(1).strip()
        expiration_date = parse_openssl_date(enddate)

        print(f"Certificate path: {CERT_PATH}")
        print(f"Certificate subject: {subject}")
        print(f"Common Name: {common_name}")
        print(f"Expiration Date: {expiration_date}")
        print("Certificate verification successful")
        return 0
    except Exception as exc:
        print(f"Certificate verification failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
