class Record:
    def __init__(self, record_id, parent_id):
        self.record_id = record_id
        self.parent_id = parent_id


class Node:
    def __init__(self, node_id):
        self.node_id = node_id
        self.children = []


def BuildTree(records):
    if not records:
        return None

    record_count = len(records)
    ordered_records = [None] * record_count
    nodes = [None] * record_count

    for record in records:
        record_id = record.record_id
        if (
            record_id < 0
            or record_id >= record_count
            or ordered_records[record_id] is not None
        ):
            raise ValueError("Record id is invalid or out of order.")

        ordered_records[record_id] = record
        nodes[record_id] = Node(record_id)

    for record_id, record in enumerate(ordered_records):
        parent_id = record.parent_id

        if parent_id > record_id:
            raise ValueError("Node parent_id should be smaller than it's record_id.")
        if record_id == 0:
            if parent_id < 0:
                raise ValueError("Record id is invalid or out of order.")
            if parent_id != 0:
                raise ValueError("Only root should have equal record and parent id.")
        elif parent_id == record_id:
            raise ValueError("Only root should have equal record and parent id.")
        elif parent_id < 0:
            raise ValueError("Record id is invalid or out of order.")

    for record_id in range(1, record_count):
        parent_id = ordered_records[record_id].parent_id
        nodes[parent_id].children.append(nodes[record_id])

    return nodes[0]
