def proverb(*pieces, qualifier=None):
    lines = [
        f"For want of a {want} the {lost} was lost."
        for want, lost in zip(pieces, pieces[1:])
    ]

    if pieces:
        first = f"{qualifier} {pieces[0]}" if qualifier else pieces[0]
        lines.append(f"And all for the want of a {first}.")

    return lines
