def grep(pattern, flags, files):
    flag_list = flags.split() if isinstance(flags, str) else list(flags)
    flags_set = set(flag_list)

    show_line_numbers = "-n" in flags_set
    show_file_names = "-l" in flags_set
    ignore_case = "-i" in flags_set
    invert_match = "-v" in flags_set
    match_entire_line = "-x" in flags_set

    results = []
    for filename in files:
        with open(filename, "r") as file:
            lines = file.read().splitlines()

        file_has_match = False
        for line_number, line in enumerate(lines, start=1):
            haystack = line.lower() if ignore_case else line
            needle = pattern.lower() if ignore_case else pattern

            is_match = haystack == needle if match_entire_line else needle in haystack
            if invert_match:
                is_match = not is_match

            if not is_match:
                continue

            if show_file_names:
                file_has_match = True
                break

            prefix = ""
            if len(files) > 1:
                prefix += filename + ":"
            if show_line_numbers:
                prefix += str(line_number) + ":"
            results.append(prefix + line + "\n")

        if show_file_names and file_has_match:
            results.append(filename + "\n")

    return "".join(results)
