//! A doubly linked list implemented with raw pointers.
//!
//! # Safety invariants
//!
//! Every node is allocated with `Box` and is reachable from exactly one
//! `LinkedList`. For every live node:
//!
//! * `prev` points to the previous node in the same list, or is `None` for the
//!   head;
//! * `next` points to the next node in the same list, or is `None` for the
//!   tail;
//! * `LinkedList::head` is null exactly when the list is empty, and in that
//!   case `tail` is null too;
//! * `Cursor::current` is either a node belonging to the borrowed list, or
//!   `None` when that list is empty.
//!
//! Safe methods maintain these invariants. A `Cursor` has exclusive access to
//! the list for its lifetime and an `Iter` has shared access, so neither can
//! observe a node being mutated or freed through another safe path.

mod pre_implemented;

use std::ptr::NonNull;

struct Node<T> {
    elem: T,
    prev: Option<NonNull<Node<T>>>,
    next: Option<NonNull<Node<T>>>,
}

/// A doubly linked list.
///
/// `NonNull` is covariant in its pointee, so this type is covariant in `T`,
/// just like `Vec<T>`.
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

/// A mutable cursor positioned on an element of a list.
///
/// The cursor saturates at the ends: calling `next` on the tail or `prev` on
/// the head returns `None` without moving the cursor. On an empty list the
/// cursor has no current element; inserting then creates the first element.
pub struct Cursor<'a, T> {
    list: &'a mut LinkedList<T>,
    current: Option<NonNull<Node<T>>>,
}

/// A front-to-back iterator over a list.
pub struct Iter<'a, T> {
    // This reference ties the iterator's lifetime to the borrowed list and
    // prevents mutation while the iterator is alive.
    _list: &'a LinkedList<T>,
    next: Option<NonNull<Node<T>>>,
}

// Raw pointers suppress the automatic trait implementations. The list owns
// all of its nodes and only hands out references governed by Rust borrows.
unsafe impl<T: Send> Send for LinkedList<T> {}
unsafe impl<T: Sync> Sync for LinkedList<T> {}

impl<T> LinkedList<T> {
    pub fn new() -> Self {
        Self {
            head: None,
            tail: None,
            len: 0,
        }
    }

    /// Allocate a node that is not linked into any list yet.
    fn alloc_node(elem: T) -> NonNull<Node<T>> {
        let boxed = Box::new(Node {
            elem,
            prev: None,
            next: None,
        });
        // SAFETY: `Box::into_raw` never returns null.
        unsafe { NonNull::new_unchecked(Box::into_raw(boxed)) }
    }

    // You may be wondering why it's necessary to have is_empty()
    // when it can easily be determined from len().
    // It's good custom to have both because len() can be expensive for some types,
    // whereas is_empty() is almost always cheap.
    // (Also ask yourself whether len() is expensive for LinkedList)
    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    pub fn len(&self) -> usize {
        self.len
    }

    /// Return a cursor positioned on the front element
    pub fn cursor_front(&mut self) -> Cursor<'_, T> {
        Cursor {
            current: self.head,
            list: self,
        }
    }

    /// Return a cursor positioned on the back element
    pub fn cursor_back(&mut self) -> Cursor<'_, T> {
        Cursor {
            current: self.tail,
            list: self,
        }
    }

    /// Return an iterator that moves from front to back
    pub fn iter(&self) -> Iter<'_, T> {
        Iter {
            _list: self,
            next: self.head,
        }
    }
}

impl<T> Default for LinkedList<T> {
    fn default() -> Self {
        Self::new()
    }
}

// the cursor is expected to act as if it is at the position of an element
// and it also has to work with and be able to insert into an empty list.
impl<T> Cursor<'_, T> {
    /// Take a mutable reference to the current element
    pub fn peek_mut(&mut self) -> Option<&mut T> {
        let mut current = self.current?;
        // SAFETY: `current` points to a live node in the exclusively borrowed
        // list, and the returned mutable reference is tied to `&mut self`.
        Some(unsafe { &mut current.as_mut().elem })
    }

    /// Move one position forward (towards the back) and
    /// return a reference to the new position
    #[allow(clippy::should_implement_trait)]
    pub fn next(&mut self) -> Option<&mut T> {
        let current = self.current?;
        // SAFETY: `current` points to a live node and the cursor has exclusive
        // access to the list, so reading its link is safe.
        let mut next = unsafe { current.as_ref() }.next?;
        self.current = Some(next);
        // SAFETY: `next` is a live, uniquely reachable node in this list and
        // the returned reference is tied to `&mut self`.
        Some(unsafe { &mut next.as_mut().elem })
    }

    /// Move one position backward (towards the front) and
    /// return a reference to the new position
    pub fn prev(&mut self) -> Option<&mut T> {
        let current = self.current?;
        // SAFETY: `current` points to a live node and the cursor has exclusive
        // access to the list, so reading its link is safe.
        let mut prev = unsafe { current.as_ref() }.prev?;
        self.current = Some(prev);
        // SAFETY: `prev` is a live, uniquely reachable node in this list and
        // the returned reference is tied to `&mut self`.
        Some(unsafe { &mut prev.as_mut().elem })
    }

    /// Remove and return the element at the current position and move the cursor
    /// to the neighboring element that's closest to the back. This can be
    /// either the next or previous position.
    pub fn take(&mut self) -> Option<T> {
        let current = self.current?;

        // SAFETY: `current` is a live node owned by the borrowed list. The
        // cursor's exclusive borrow prevents simultaneous access to its links.
        let (prev, next) = unsafe {
            let node = current.as_ref();
            (node.prev, node.next)
        };

        // The closest neighbor towards the back is `next`; if there is no
        // next, wrap to `prev`.
        self.current = next.or(prev);

        // Link around the node being removed.
        match prev {
            // SAFETY: `prev` is a distinct live node in the same list.
            Some(mut prev) => unsafe { prev.as_mut().next = next },
            None => self.list.head = next,
        }
        match next {
            // SAFETY: `next` is a distinct live node in the same list.
            Some(mut next) => unsafe { next.as_mut().prev = prev },
            None => self.list.tail = prev,
        }

        self.list.len -= 1;

        // SAFETY: `current` was allocated with `Box::new`/`Box::into_raw` in
        // `alloc_node`, and the code above unlinked it exactly once. No other
        // live reference to this node exists. Moving out of the box returns
        // the element and deallocates the node storage.
        let node = *unsafe { Box::from_raw(current.as_ptr()) };
        Some(node.elem)
    }

    pub fn insert_after(&mut self, element: T) {
        let mut new_node = LinkedList::alloc_node(element);

        let mut current = match self.current {
            Some(current) => current,
            None => {
                // There is no current element only in an empty list, so this
                // insertion creates the sole element.
                debug_assert!(self.list.head.is_none());
                debug_assert!(self.list.tail.is_none());
                self.list.head = Some(new_node);
                self.list.tail = Some(new_node);
                self.current = Some(new_node);
                self.list.len += 1;
                return;
            }
        };

        // SAFETY: `current` is a live node in the exclusively borrowed list.
        let next = unsafe { current.as_ref() }.next;

        // SAFETY: `new_node` is a fresh unique allocation and `current`/`next`
        // are distinct live nodes in this list. The cursor stays on `current`,
        // as expected by repeated insertions at one position.
        unsafe {
            new_node.as_mut().prev = Some(current);
            new_node.as_mut().next = next;
            current.as_mut().next = Some(new_node);
        }

        match next {
            // SAFETY: `next` is a distinct live node in the same list.
            Some(mut next) => unsafe { next.as_mut().prev = Some(new_node) },
            None => self.list.tail = Some(new_node),
        }

        self.list.len += 1;
    }

    pub fn insert_before(&mut self, element: T) {
        let mut new_node = LinkedList::alloc_node(element);

        let mut current = match self.current {
            Some(current) => current,
            None => {
                // There is no current element only in an empty list, so this
                // insertion creates the sole element.
                debug_assert!(self.list.head.is_none());
                debug_assert!(self.list.tail.is_none());
                self.list.head = Some(new_node);
                self.list.tail = Some(new_node);
                self.current = Some(new_node);
                self.list.len += 1;
                return;
            }
        };

        // SAFETY: `current` is a live node in the exclusively borrowed list.
        let prev = unsafe { current.as_ref() }.prev;

        // SAFETY: `new_node` is a fresh unique allocation and `current`/`prev`
        // are distinct live nodes in this list. The cursor stays on `current`.
        unsafe {
            new_node.as_mut().prev = prev;
            new_node.as_mut().next = Some(current);
            current.as_mut().prev = Some(new_node);
        }

        match prev {
            // SAFETY: `prev` is a distinct live node in the same list.
            Some(mut prev) => unsafe { prev.as_mut().next = Some(new_node) },
            None => self.list.head = Some(new_node),
        }

        self.list.len += 1;
    }
}

impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    fn next(&mut self) -> Option<&'a T> {
        let current = self.next?;
        // SAFETY: every pointer stored in `next` points to a live node owned by
        // the list borrowed by `self`. The shared borrow prevents mutation or
        // deallocation for the lifetime `'a`.
        let node = unsafe { current.as_ref() };
        self.next = node.next;
        Some(&node.elem)
    }
}

impl<T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        while let Some(head) = self.head {
            // SAFETY: `head` points to a live node still owned by this list;
            // during `drop` there is no cursor or iterator using it.
            let next = unsafe { head.as_ref() }.next;
            self.head = next;
            self.len -= 1;

            // SAFETY: `head` was allocated with `Box::new`/`Box::into_raw`
            // and was just unlinked from the list, so it is dropped exactly
            // once here.
            unsafe { drop(Box::from_raw(head.as_ptr())) };
        }
        self.tail = None;
    }
}
