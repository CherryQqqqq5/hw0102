#!/usr/bin/env python3
"""Modernized climate analysis for the sample station temperature data."""

import configparser
from pathlib import Path

import numpy as np
import pandas as pd


BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "climate_analyzer" / "sample_data" / "climate_data.csv"
CONFIG_PATH = BASE_DIR / "climate_analyzer" / "config.ini"


def read_config(path: Path = CONFIG_PATH) -> configparser.ConfigParser:
    """Read the legacy configuration file using Python 3's configparser."""
    config = configparser.ConfigParser()
    config.read(path, encoding="utf-8")
    return config


def load_temperature_data(path: Path = DATA_PATH) -> pd.DataFrame:
    """Load station temperatures from a UTF-8 encoded CSV file."""
    data = pd.read_csv(path, encoding="utf-8")
    required_columns = {"station_id", "temperature"}
    missing_columns = required_columns.difference(data.columns)
    if missing_columns:
        missing = ", ".join(sorted(missing_columns))
        raise ValueError(f"Missing required column(s) in {path}: {missing}")

    data["station_id"] = pd.to_numeric(data["station_id"], errors="raise").astype("int64")
    data["temperature"] = pd.to_numeric(data["temperature"], errors="raise")
    return data


def calculate_station_means(data: pd.DataFrame) -> dict[int, float]:
    """Compute the mean temperature for each station in the dataset."""
    means: dict[int, float] = {}
    for station_id, group in data.groupby("station_id", sort=True):
        temperatures = np.asarray(group["temperature"], dtype=float)
        means[int(station_id)] = float(np.mean(temperatures))
    return means


def main() -> None:
    # Reading the config preserves the legacy workflow and verifies that its
    # UTF-8 content is handled correctly on modern Python.
    read_config()

    data = load_temperature_data()
    for station_id, mean_temperature in calculate_station_means(data).items():
        print(f"Station {station_id} mean temperature: {mean_temperature:.1f}°C")


if __name__ == "__main__":
    main()
