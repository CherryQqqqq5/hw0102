import json


class RestAPI:
    def __init__(self, database=None):
        self.database = database if database is not None else {"users": []}
        if "users" not in self.database:
            self.database["users"] = []

    @staticmethod
    def _payload(payload):
        if payload is None:
            return {}
        if isinstance(payload, (str, bytes, bytearray)):
            return json.loads(payload)
        return dict(payload)

    @staticmethod
    def _balance(user):
        return float(sum(user.get("owed_by", {}).values()) - sum(user.get("owes", {}).values()))

    def _users(self):
        return self.database["users"]

    def _find_user(self, name):
        for user in self._users():
            if user.get("name") == name:
                return user
        return None

    def _users_response(self, users):
        return json.dumps({"users": sorted(users, key=lambda user: user["name"])})

    @staticmethod
    def _normalize_user(user):
        user.setdefault("owes", {})
        user.setdefault("owed_by", {})
        user["owes"] = {name: float(amount) for name, amount in user["owes"].items()}
        user["owed_by"] = {name: float(amount) for name, amount in user["owed_by"].items()}
        user["balance"] = RestAPI._balance(user)
        return user

    def get(self, url, payload=None):
        data = self._payload(payload)
        if url == "/users":
            names = data.get("users")
            if names is None:
                return self._users_response(self._users())
            wanted = set(names)
            return self._users_response(
                [user for user in self._users() if user.get("name") in wanted]
            )
        raise ValueError("Unsupported URL: {}".format(url))

    def post(self, url, payload=None):
        data = self._payload(payload)
        if url == "/add":
            name = data["user"]
            user = self._normalize_user({"name": name, "owes": {}, "owed_by": {}, "balance": 0.0})
            self._users().append(user)
            return json.dumps(user)

        if url == "/iou":
            lender_name = data["lender"]
            borrower_name = data["borrower"]
            amount = float(data["amount"])
            lender = self._find_user(lender_name)
            borrower = self._find_user(borrower_name)

            self._normalize_user(lender)
            self._normalize_user(borrower)

            # Positive net means the borrower owes the lender; negative means
            # the lender owes the borrower. Existing debts in either direction
            # are cancelled before the new IOU is applied.
            net = (
                borrower["owes"].get(lender_name, 0.0)
                - lender["owes"].get(borrower_name, 0.0)
                + amount
            )

            borrower["owes"].pop(lender_name, None)
            lender["owed_by"].pop(borrower_name, None)
            lender["owes"].pop(borrower_name, None)
            borrower["owed_by"].pop(lender_name, None)

            if net > 0:
                borrower["owes"][lender_name] = net
                lender["owed_by"][borrower_name] = net
            elif net < 0:
                lender["owes"][borrower_name] = -net
                borrower["owed_by"][lender_name] = -net

            lender["balance"] = self._balance(lender)
            borrower["balance"] = self._balance(borrower)
            return self._users_response([lender, borrower])

        raise ValueError("Unsupported URL: {}".format(url))
