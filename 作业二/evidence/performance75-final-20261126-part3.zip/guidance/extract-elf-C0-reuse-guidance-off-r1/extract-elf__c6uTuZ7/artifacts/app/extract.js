'use strict';

const fs = require('fs');

function fail(message) {
  process.stderr.write(message + '\n');
  process.exit(1);
}

function main() {
  const path = process.argv[2];
  if (!path) fail('usage: node extract.js <elf-file>');

  const buf = fs.readFileSync(path);
  if (buf.length < 16 || buf[0] !== 0x7f || buf[1] !== 0x45 ||
      buf[2] !== 0x4c || buf[3] !== 0x46) {
    fail('not an ELF file');
  }

  const elfClass = buf[4];
  const elfData = buf[5];
  if (elfClass !== 1 && elfClass !== 2) fail('unsupported ELF class');
  if (elfData !== 1 && elfData !== 2) fail('unsupported ELF data encoding');
  const littleEndian = elfData === 1;
  const is64 = elfClass === 2;

  function u16(off) {
    return littleEndian ? buf.readUInt16LE(off) : buf.readUInt16BE(off);
  }
  function u32(off) {
    return littleEndian ? buf.readUInt32LE(off) : buf.readUInt32BE(off);
  }
  function u64(off) {
    return littleEndian ? buf.readBigUInt64LE(off) : buf.readBigUInt64BE(off);
  }

  // ELF header fields needed to locate the program header table.
  const phoff = Number(is64 ? u64(32) : BigInt(u32(28)));
  const phentsize = u16(is64 ? 54 : 42);
  const phnum = u16(is64 ? 56 : 44);
  const minPhentsize = is64 ? 56 : 32;

  if (phentsize < minPhentsize) fail('invalid program header entry size');

  const result = Object.create(null);
  const word = Buffer.alloc(4);

  for (let i = 0; i < phnum; i++) {
    const ph = phoff + i * phentsize;
    if (ph < 0 || ph + minPhentsize > buf.length) fail('program header table out of bounds');
    if (u32(ph) !== 1) continue; // PT_LOAD

    const p_offset = is64 ? u64(ph + 8) : BigInt(u32(ph + 4));
    const p_vaddr = is64 ? u64(ph + 16) : BigInt(u32(ph + 8));
    const p_filesz = is64 ? u64(ph + 32) : BigInt(u32(ph + 16));
    const p_memsz = is64 ? u64(ph + 40) : BigInt(u32(ph + 20));

    // Matches range(0, p_memsz - 3, 4) in the reference-style checker.
    for (let delta = 0n; delta + 3n < p_memsz; delta += 4n) {
      word.fill(0);
      const available = p_filesz > delta ? (p_filesz - delta < 4n ? p_filesz - delta : 4n) : 0n;
      if (available > 0n) {
        const src = p_offset + delta;
        if (src >= 0n && src < BigInt(buf.length)) {
          const canCopy = available < BigInt(buf.length) - src ? available : BigInt(buf.length) - src;
          buf.copy(word, 0, Number(src), Number(src + canCopy));
        }
      }
      const value = littleEndian ? word.readUInt32LE(0) : word.readUInt32BE(0);
      result[(p_vaddr + delta).toString()] = value;
    }
  }

  process.stdout.write(JSON.stringify(result));
}

main();
