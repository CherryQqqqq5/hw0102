class Record:
    def __init__(self, record_id, parent_id):
        self.record_id = record_id
        self.parent_id = parent_id


class Node:
    def __init__(self, node_id):
        self.node_id = node_id
        self.children = []


def BuildTree(records):
    if not records:
        return None

    records_by_id = {}
    for record in records:
        record_id = record.record_id
        if record_id < 0 or record_id >= len(records):
            raise ValueError("Record id is invalid or out of order.")
        if record_id in records_by_id:
            raise ValueError("Record id is invalid or out of order.")
        records_by_id[record_id] = record

    nodes = {}
    for record_id in range(len(records)):
        record = records_by_id[record_id]
        parent_id = record.parent_id

        if record_id == parent_id:
            if record_id != 0:
                raise ValueError("Only root should have equal record and parent id.")
        elif parent_id < 0 or parent_id > record_id:
            raise ValueError("Node parent_id should be smaller than it's record_id.")

        node = Node(record_id)
        nodes[record_id] = node
        if record_id != 0:
            nodes[parent_id].children.append(node)

    return nodes[0]
