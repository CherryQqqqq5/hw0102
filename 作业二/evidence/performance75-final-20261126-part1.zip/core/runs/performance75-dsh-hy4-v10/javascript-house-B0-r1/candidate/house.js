const SUBJECTS = [
  'the house that Jack built.',
  'the malt',
  'the rat',
  'the cat',
  'the dog',
  'the cow with the crumpled horn',
  'the maiden all forlorn',
  'the man all tattered and torn',
  'the priest all shaven and shorn',
  'the rooster that crowed in the morn',
  'the farmer sowing his corn',
  'the horse and the hound and the horn',
];

const ACTIONS = [
  '',
  'lay in',
  'ate',
  'killed',
  'worried',
  'tossed',
  'milked',
  'kissed',
  'married',
  'woke',
  'kept',
  'belonged to',
];

export class House {
  static verse(number) {
    const lines = [`This is ${SUBJECTS[number - 1]}`];

    for (let index = number; index > 1; index -= 1) {
      lines.push(`that ${ACTIONS[index - 1]} ${SUBJECTS[index - 2]}`);
    }

    return lines;
  }

  static verses(start, end) {
    const lines = [];

    for (let number = start; number <= end; number += 1) {
      if (number > start) {
        lines.push('');
      }

      lines.push(...House.verse(number));
    }

    return lines;
  }
}
