use std::marker::PhantomData;
use std::ptr::{addr_of, addr_of_mut, null_mut};

// this module adds some functionality based on the required implementations
// here like: `LinkedList::pop_back` or `Clone for LinkedList<T>`
// You are free to use anything in it, but it's mainly for the test framework.
mod pre_implemented;

struct Node<T> {
    elem: T,
    // Type-erased so that `LinkedList<T>` stays covariant in `T`.
    // Every non-null pointer is a `*mut Node<T>` cast to `*mut ()`.
    prev: *mut (),
    next: *mut (),
}

/// A doubly linked list that owns all of its nodes.
///
/// # Safety invariants
///
/// - `head` and `tail` are null exactly when `len == 0`. Otherwise they point
///   to the first and last live node of the list, respectively.
/// - Every live node is reachable from `head` by following `next`, is reachable
///   from `tail` by following `prev`, and is owned exactly once by this list.
/// - For every live node, `prev` and `next` are either null (at the ends) or
///   point to the adjacent live node in the same list.
/// - All type-erased pointers originate from `Box::into_raw` on a
///   `Box<Node<T>>` belonging to this list, so casting them back to
///   `*mut Node<T>` is always valid.
pub struct LinkedList<T> {
    head: *mut (),
    tail: *mut (),
    len: usize,
    // Expresses ownership of the nodes and keeps the type covariant in `T`.
    _marker: PhantomData<Box<Node<T>>>,
}

/// A cursor positioned on an element of a list.
///
/// `current` is either null (the list is empty) or points to a live node owned
/// by `list`. The `&mut LinkedList<T>` guarantees exclusive access to the whole
/// list for the lifetime of the cursor.
pub struct Cursor<'a, T> {
    list: &'a mut LinkedList<T>,
    current: *mut (),
}

/// An iterator over shared references to the elements of a list.
///
/// `current` is either null or points to a live node owned by the borrowed
/// list. `PhantomData<&'a T>` ties the iterator to the list's lifetime and
/// makes the iterator covariant in both `'a` and `T`.
pub struct Iter<'a, T> {
    current: *mut (),
    _marker: PhantomData<&'a T>,
}

/// Allocate a node with the given links.
///
/// # Safety
///
/// `prev` and `next` must be either null or pointers to live nodes in the same
/// list, so that storing them preserves the list's linking invariants.
unsafe fn allocate_node<T>(element: T, prev: *mut (), next: *mut ()) -> *mut () {
    let node = Box::new(Node {
        elem: element,
        prev,
        next,
    });
    Box::into_raw(node) as *mut ()
}

impl<T> LinkedList<T> {
    pub fn new() -> Self {
        Self {
            head: null_mut(),
            tail: null_mut(),
            len: 0,
            _marker: PhantomData,
        }
    }

    // You may be wondering why it's necessary to have is_empty()
    // when it can easily be determined from len().
    // It's good custom to have both because len() can be expensive for some types,
    // whereas is_empty() is almost always cheap.
    // (Also ask yourself whether len() is expensive for LinkedList)
    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    pub fn len(&self) -> usize {
        self.len
    }

    /// Return a cursor positioned on the front element
    pub fn cursor_front(&mut self) -> Cursor<'_, T> {
        let current = self.head;
        Cursor {
            list: self,
            current,
        }
    }

    /// Return a cursor positioned on the back element
    pub fn cursor_back(&mut self) -> Cursor<'_, T> {
        let current = self.tail;
        Cursor {
            list: self,
            current,
        }
    }

    /// Return an iterator that moves from front to back
    pub fn iter(&self) -> Iter<'_, T> {
        Iter {
            current: self.head,
            _marker: PhantomData,
        }
    }
}

impl<T> Default for LinkedList<T> {
    fn default() -> Self {
        Self::new()
    }
}

// the cursor is expected to act as if it is at the position of an element
// and it also has to work with and be able to insert into an empty list.
impl<T> Cursor<'_, T> {
    /// Take a mutable reference to the current element
    pub fn peek_mut(&mut self) -> Option<&mut T> {
        if self.current.is_null() {
            return None;
        }

        let node = self.current as *mut Node<T>;
        // SAFETY: `current` is non-null and, by the cursor and list invariants,
        // points to a live node owned by `list`. The cursor holds `&mut list`,
        // so no other reference to this element can exist.
        let elem = unsafe { addr_of_mut!((*node).elem) };
        // SAFETY: `elem` points to the live `T` of that node, and the returned
        // reference is tied to `&mut self`, so it cannot alias another borrow.
        Some(unsafe { &mut *elem })
    }

    /// Move one position forward (towards the back) and
    /// return a reference to the new position
    #[allow(clippy::should_implement_trait)]
    pub fn next(&mut self) -> Option<&mut T> {
        if self.current.is_null() {
            return None;
        }

        let node = self.current as *mut Node<T>;
        // SAFETY: `current` points to a live node, so its `next` field is
        // initialized and may be read.
        let next = unsafe { (*node).next };
        if next.is_null() {
            // Already at the back; stay in place and report that there is no
            // new position.
            return None;
        }

        self.current = next;
        self.peek_mut()
    }

    /// Move one position backward (towards the front) and
    /// return a reference to the new position
    pub fn prev(&mut self) -> Option<&mut T> {
        if self.current.is_null() {
            return None;
        }

        let node = self.current as *mut Node<T>;
        // SAFETY: `current` points to a live node, so its `prev` field is
        // initialized and may be read.
        let prev = unsafe { (*node).prev };
        if prev.is_null() {
            // Already at the front; stay in place and report that there is no
            // new position.
            return None;
        }

        self.current = prev;
        self.peek_mut()
    }

    /// Remove and return the element at the current position and move the cursor
    /// to the neighboring element that's closest to the back. This can be
    /// either the next or previous position.
    pub fn take(&mut self) -> Option<T> {
        if self.current.is_null() {
            return None;
        }

        let node = self.current as *mut Node<T>;
        // SAFETY: `current` points to a live node owned by `list`. We read its
        // links, relink its neighbours, and finally reclaim exactly this node.
        unsafe {
            let prev = (*node).prev;
            let next = (*node).next;

            // The neighbour closest to the back is `next`, if it exists.
            self.current = if next.is_null() { prev } else { next };

            if prev.is_null() {
                self.list.head = next;
            } else {
                (*(prev as *mut Node<T>)).next = next;
            }

            if next.is_null() {
                self.list.tail = prev;
            } else {
                (*(next as *mut Node<T>)).prev = prev;
            }

            self.list.len -= 1;

            // SAFETY: `node` came from `Box::into_raw` and is no longer linked
            // into the list, so it is safe to reconstruct and drop the Box.
            // Moving `elem` out avoids dropping the value twice.
            let boxed = Box::from_raw(node);
            let Node { elem, .. } = *boxed;
            Some(elem)
        }
    }

    pub fn insert_after(&mut self, element: T) {
        if self.current.is_null() {
            // The list is empty: the new node becomes the only node, and the
            // cursor moves onto it.
            // SAFETY: both links are null, which is valid for an empty list.
            let new_node = unsafe { allocate_node(element, null_mut(), null_mut()) };
            self.list.head = new_node;
            self.list.tail = new_node;
            self.list.len += 1;
            self.current = new_node;
            return;
        }

        let node = self.current as *mut Node<T>;
        // SAFETY: `current` points to a live node, and `next` is either null or
        // the following live node in the list.
        unsafe {
            let next = (*node).next;
            let new_node = allocate_node(element, self.current, next);

            (*node).next = new_node;
            if next.is_null() {
                self.list.tail = new_node;
            } else {
                (*(next as *mut Node<T>)).prev = new_node;
            }

            self.list.len += 1;
            // The cursor stays on the original node, so a sequence of
            // `insert_after` calls accumulates new nodes in front of the old
            // successor while keeping this cursor position stable.
        }
    }

    pub fn insert_before(&mut self, element: T) {
        if self.current.is_null() {
            // The list is empty: the new node becomes the only node, and the
            // cursor moves onto it.
            // SAFETY: both links are null, which is valid for an empty list.
            let new_node = unsafe { allocate_node(element, null_mut(), null_mut()) };
            self.list.head = new_node;
            self.list.tail = new_node;
            self.list.len += 1;
            self.current = new_node;
            return;
        }

        let node = self.current as *mut Node<T>;
        // SAFETY: `current` points to a live node, and `prev` is either null or
        // the preceding live node in the list.
        unsafe {
            let prev = (*node).prev;
            let new_node = allocate_node(element, prev, self.current);

            (*node).prev = new_node;
            if prev.is_null() {
                self.list.head = new_node;
            } else {
                (*(prev as *mut Node<T>)).next = new_node;
            }

            self.list.len += 1;
            // The cursor deliberately stays on the original node, so repeated
            // `insert_before` calls insert in insertion order.
        }
    }
}

impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    fn next(&mut self) -> Option<&'a T> {
        if self.current.is_null() {
            return None;
        }

        let node = self.current as *mut Node<T>;
        // SAFETY: `current` points to a live node owned by the list that this
        // iterator borrows. Reading `next` advances through only live nodes.
        let next = unsafe { (*node).next };
        self.current = next;

        // SAFETY: `elem` belongs to a node still owned by the borrowed list,
        // which outlives `'a`. Only shared references are handed out, and the
        // list cannot be mutated while the iterator (and thus `'a`) is alive.
        unsafe { Some(&*addr_of!((*node).elem)) }
    }
}

impl<T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        let mut current = self.head;
        while !current.is_null() {
            let node = current as *mut Node<T>;
            // SAFETY: `current` points to a live node. Save `next` before
            // reclaiming the node, since dropping it may run `T::drop`.
            let next = unsafe { (*node).next };

            // SAFETY: every node was allocated with `Box::new` and converted
            // with `Box::into_raw`, and each is reclaimed exactly once here.
            unsafe {
                drop(Box::from_raw(node));
            }

            current = next;
        }
    }
}

// The nodes are owned exclusively by the list, so moving the list to another
// thread is safe exactly when moving its elements is safe.
unsafe impl<T: Send> Send for LinkedList<T> {}

// Shared access to the list only exposes shared references to its elements
// (via `iter`), so sharing the list is safe exactly when sharing `T` is safe.
unsafe impl<T: Sync> Sync for LinkedList<T> {}
