import copy
import json


class RestAPI:
    def __init__(self, database=None):
        if database is None:
            database = {"users": []}
        self.database = copy.deepcopy(database)
        self.database.setdefault("users", [])
        self._normalize_all()
        self._users = {user["name"]: user for user in self.database["users"]}

    @staticmethod
    def _parse_payload(payload):
        if payload is None:
            return {}
        if isinstance(payload, str):
            return json.loads(payload)
        return payload

    @staticmethod
    def _balance(user):
        return float(sum(user["owed_by"].values()) - sum(user["owes"].values()))

    def _normalize_all(self):
        for user in self.database["users"]:
            user.setdefault("owes", {})
            user.setdefault("owed_by", {})
            user["balance"] = self._balance(user)

    def _user_view(self, user):
        return {
            "name": user["name"],
            "owes": dict(user["owes"]),
            "owed_by": dict(user["owed_by"]),
            "balance": self._balance(user),
        }

    def _users_view(self, names=None):
        if names is None:
            users = list(self.database["users"])
        else:
            users = [self._users[name] for name in names if name in self._users]
        return [self._user_view(user) for user in sorted(users, key=lambda user: user["name"])]

    def _settle_iou(self, lender, borrower, amount):
        lender_name = lender["name"]
        borrower_name = borrower["name"]

        # A positive net means the borrower owes the lender; a negative net
        # means the lender owes the borrower.
        net = (
            lender["owed_by"].get(borrower_name, 0.0)
            - lender["owes"].get(borrower_name, 0.0)
            + amount
        )

        lender["owes"].pop(borrower_name, None)
        lender["owed_by"].pop(borrower_name, None)
        borrower["owes"].pop(lender_name, None)
        borrower["owed_by"].pop(lender_name, None)

        if net > 0:
            lender["owed_by"][borrower_name] = net
            borrower["owes"][lender_name] = net
        elif net < 0:
            lender["owes"][borrower_name] = -net
            borrower["owed_by"][lender_name] = -net

        lender["balance"] = self._balance(lender)
        borrower["balance"] = self._balance(borrower)

    def get(self, url, payload=None):
        if url == "/users":
            data = self._parse_payload(payload)
            return json.dumps({"users": self._users_view(data.get("users"))})
        raise ValueError(f"Unsupported GET URL: {url}")

    def post(self, url, payload=None):
        data = self._parse_payload(payload)

        if url == "/add":
            user = {
                "name": data["user"],
                "owes": {},
                "owed_by": {},
                "balance": 0.0,
            }
            self.database["users"].append(user)
            self._users[user["name"]] = user
            return json.dumps(self._user_view(user))

        if url == "/iou":
            lender = self._users[data["lender"]]
            borrower = self._users[data["borrower"]]
            self._settle_iou(lender, borrower, float(data["amount"]))
            return json.dumps(
                {"users": self._users_view([lender["name"], borrower["name"]])}
            )

        raise ValueError(f"Unsupported POST URL: {url}")
