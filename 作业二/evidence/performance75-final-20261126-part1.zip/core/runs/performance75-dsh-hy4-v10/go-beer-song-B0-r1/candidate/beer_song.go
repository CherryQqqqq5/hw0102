package beer

import (
	"fmt"
	"strings"
)

const maxBottles = 99

func Song() string {
	song, _ := Verses(maxBottles, 0)
	return song
}

func Verses(start, stop int) (string, error) {
	if start < 0 || stop < 0 || start > maxBottles || stop > maxBottles || start < stop {
		return "", fmt.Errorf("invalid verse range: %d to %d", start, stop)
	}

	var song strings.Builder
	song.Grow((start - stop + 1) * 128)
	for n := start; n >= stop; n-- {
		verse, _ := Verse(n)
		song.WriteString(verse)
		song.WriteString("\n")
	}
	return song.String(), nil
}

func Verse(n int) (string, error) {
	if n < 0 || n > maxBottles {
		return "", fmt.Errorf("invalid verse number: %d", n)
	}

	var verse strings.Builder
	verse.Grow(160)
	verse.WriteString(capitalize(bottles(n)))
	verse.WriteString(" of beer on the wall, ")
	verse.WriteString(bottles(n))
	verse.WriteString(" of beer.\n")

	if n == 0 {
		verse.WriteString("Go to the store and buy some more, ")
		verse.WriteString(bottles(maxBottles))
		verse.WriteString(" of beer on the wall.\n")
		return verse.String(), nil
	}

	if n == 1 {
		verse.WriteString("Take it down and pass it around, ")
	} else {
		verse.WriteString("Take one down and pass it around, ")
	}
	verse.WriteString(bottles(n - 1))
	verse.WriteString(" of beer on the wall.\n")
	return verse.String(), nil
}

func bottles(n int) string {
	switch n {
	case 0:
		return "no more bottles"
	case 1:
		return "1 bottle"
	default:
		return fmt.Sprintf("%d bottles", n)
	}
}

func capitalize(s string) string {
	if s == "" {
		return s
	}
	return strings.ToUpper(s[:1]) + s[1:]
}
