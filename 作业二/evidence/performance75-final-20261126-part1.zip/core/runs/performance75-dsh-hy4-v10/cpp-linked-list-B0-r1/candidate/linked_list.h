#pragma once

#include <cstddef>
#include <stdexcept>
#include <utility>

namespace linked_list {

template <typename T>
class List {
private:
    struct Node {
        T value;
        Node* prev;
        Node* next;

        explicit Node(const T& value, Node* prev = nullptr, Node* next = nullptr)
            : value(value), prev(prev), next(next) {}

        explicit Node(T&& value, Node* prev = nullptr, Node* next = nullptr)
            : value(std::move(value)), prev(prev), next(next) {}
    };

    Node* head_;
    Node* tail_;
    std::size_t count_;

    void clear() noexcept {
        Node* current = head_;
        while (current != nullptr) {
            Node* next = current->next;
            delete current;
            current = next;
        }
        head_ = nullptr;
        tail_ = nullptr;
        count_ = 0;
    }

    void append(Node* node) noexcept {
        if (tail_ != nullptr) {
            tail_->next = node;
        } else {
            head_ = node;
        }
        tail_ = node;
        ++count_;
    }

    void prepend(Node* node) noexcept {
        if (head_ != nullptr) {
            head_->prev = node;
        } else {
            tail_ = node;
        }
        head_ = node;
        ++count_;
    }

public:
    List() noexcept : head_(nullptr), tail_(nullptr), count_(0) {}

    List(const List& other) : List() {
        for (Node* current = other.head_; current != nullptr; current = current->next) {
            push(current->value);
        }
    }

    List(List&& other) noexcept
        : head_(other.head_), tail_(other.tail_), count_(other.count_) {
        other.head_ = nullptr;
        other.tail_ = nullptr;
        other.count_ = 0;
    }

    ~List() {
        clear();
    }

    List& operator=(const List& other) {
        if (this != &other) {
            List copy(other);
            swap(copy);
        }
        return *this;
    }

    List& operator=(List&& other) noexcept {
        if (this != &other) {
            clear();
            head_ = other.head_;
            tail_ = other.tail_;
            count_ = other.count_;
            other.head_ = nullptr;
            other.tail_ = nullptr;
            other.count_ = 0;
        }
        return *this;
    }

    void swap(List& other) noexcept {
        using std::swap;
        swap(head_, other.head_);
        swap(tail_, other.tail_);
        swap(count_, other.count_);
    }

    void push(const T& value) {
        append(new Node(value, tail_, nullptr));
    }

    void push(T&& value) {
        append(new Node(std::move(value), tail_, nullptr));
    }

    T pop() {
        if (head_ == nullptr) {
            throw std::out_of_range("pop from an empty list");
        }

        Node* node = tail_;
        T value = std::move(node->value);

        tail_ = node->prev;
        if (tail_ != nullptr) {
            tail_->next = nullptr;
        } else {
            head_ = nullptr;
        }

        delete node;
        --count_;
        return value;
    }

    void unshift(const T& value) {
        prepend(new Node(value, nullptr, head_));
    }

    void unshift(T&& value) {
        prepend(new Node(std::move(value), nullptr, head_));
    }

    T shift() {
        if (head_ == nullptr) {
            throw std::out_of_range("shift from an empty list");
        }

        Node* node = head_;
        T value = std::move(node->value);

        head_ = node->next;
        if (head_ != nullptr) {
            head_->prev = nullptr;
        } else {
            tail_ = nullptr;
        }

        delete node;
        --count_;
        return value;
    }

    std::size_t count() const noexcept {
        return count_;
    }

    bool erase(const T& value) {
        Node* current = head_;
        while (current != nullptr) {
            if (current->value == value) {
                if (current->prev != nullptr) {
                    current->prev->next = current->next;
                } else {
                    head_ = current->next;
                }

                if (current->next != nullptr) {
                    current->next->prev = current->prev;
                } else {
                    tail_ = current->prev;
                }

                delete current;
                --count_;
                return true;
            }
            current = current->next;
        }
        return false;
    }
};

}  // namespace linked_list
