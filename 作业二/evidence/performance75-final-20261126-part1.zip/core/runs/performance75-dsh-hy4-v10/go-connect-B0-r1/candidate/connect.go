package connect

import (
	"fmt"
	"strings"
)

// ResultOf returns the winner of the given Hex board, or "" if there is none.
//
// O connects the top and bottom sides; X connects the left and right sides.
func ResultOf(lines []string) (string, error) {
	board := make([]string, len(lines))
	width := 0

	for i, line := range lines {
		row := strings.Join(strings.Fields(line), "")
		for j := 0; j < len(row); j++ {
			switch row[j] {
			case '.', 'O', 'X':
			default:
				return "", fmt.Errorf("invalid cell %q at row %d, column %d", row[j], i, j)
			}
		}
		if i == 0 {
			width = len(row)
		} else if len(row) != width {
			return "", fmt.Errorf("row %d has length %d, want %d", i, len(row), width)
		}
		board[i] = row
	}

	if len(board) == 0 || width == 0 {
		return "", nil
	}

	if connects(board, 'X', width, func(r, c int) bool { return c == 0 }, func(r, c int) bool { return c == width-1 }) {
		return "X", nil
	}
	if connects(board, 'O', width, func(r, c int) bool { return r == 0 }, func(r, c int) bool { return r == len(board)-1 }) {
		return "O", nil
	}

	return "", nil
}

func connects(board []string, player byte, width int, onStart, onGoal func(r, c int) bool) bool {
	visited := make([][]bool, len(board))
	for r := range board {
		visited[r] = make([]bool, width)
	}

	type cell struct{ r, c int }
	queue := make([]cell, 0)

	for r := 0; r < len(board); r++ {
		for c := 0; c < width; c++ {
			if board[r][c] == player && onStart(r, c) {
				visited[r][c] = true
				queue = append(queue, cell{r, c})
			}
		}
	}

	for len(queue) > 0 {
		cur := queue[0]
		queue = queue[1:]

		if onGoal(cur.r, cur.c) {
			return true
		}

		neighbors := [6]cell{
			{cur.r, cur.c - 1},
			{cur.r, cur.c + 1},
			{cur.r - 1, cur.c},
			{cur.r - 1, cur.c + 1},
			{cur.r + 1, cur.c},
			{cur.r + 1, cur.c - 1},
		}
		for _, next := range neighbors {
			if next.r < 0 || next.r >= len(board) || next.c < 0 || next.c >= width {
				continue
			}
			if visited[next.r][next.c] || board[next.r][next.c] != player {
				continue
			}
			visited[next.r][next.c] = true
			queue = append(queue, next)
		}
	}

	return false
}
