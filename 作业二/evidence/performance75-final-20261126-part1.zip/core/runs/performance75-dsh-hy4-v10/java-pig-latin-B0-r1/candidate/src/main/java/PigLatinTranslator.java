class PigLatinTranslator {
    public String translate(String text) {
        StringBuilder result = new StringBuilder();
        int index = 0;

        while (index < text.length()) {
            int start = index;

            if (Character.isWhitespace(text.charAt(index))) {
                while (index < text.length() && Character.isWhitespace(text.charAt(index))) {
                    index++;
                }
                result.append(text, start, index);
            } else {
                while (index < text.length() && !Character.isWhitespace(text.charAt(index))) {
                    index++;
                }
                result.append(translateWord(text.substring(start, index)));
            }
        }

        return result.toString();
    }

    private String translateWord(String word) {
        if (isVowel(word.charAt(0)) || word.startsWith("xr") || word.startsWith("yt")) {
            return word + "ay";
        }

        int splitIndex = findFirstVowelIndex(word);
        if (splitIndex == -1) {
            splitIndex = word.length();
        }

        return word.substring(splitIndex) + word.substring(0, splitIndex) + "ay";
    }

    private int findFirstVowelIndex(String word) {
        for (int i = 0; i < word.length(); i++) {
            char current = word.charAt(i);

            if (i > 0 && current == 'y') {
                return i;
            }

            if (isVowel(current)) {
                if (current == 'u' && i > 0 && word.charAt(i - 1) == 'q') {
                    continue;
                }
                return i;
            }
        }

        return -1;
    }

    private boolean isVowel(char c) {
        return c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u';
    }
}
