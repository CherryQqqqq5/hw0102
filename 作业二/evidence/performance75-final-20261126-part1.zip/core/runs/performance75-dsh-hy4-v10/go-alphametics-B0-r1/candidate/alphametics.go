package alphametics

import (
	"errors"
	"sort"
	"strings"
	"unicode"
)

type alphameticTerm struct {
	letter int
	coeff  int
}

type alphameticColumn struct {
	counts []int
	result int
}

type alphameticDPResult struct {
	residues uint16
	min      int
	max      int
}

type alphameticSolver struct {
	columns    []alphameticColumn
	digits     []int
	used       [10]bool
	leading    []bool
	maxCarryIn []int
}

func Solve(puzzle string) (map[string]int, error) {
	addends, result, letters, leading, _, err := parseAlphametic(puzzle)
	if err != nil {
		return nil, err
	}
	if len(letters) > 10 {
		return nil, errors.New("no solution")
	}

	maxLen := len(result)
	for _, word := range addends {
		if len(word) > maxLen {
			maxLen = len(word)
		}
	}

	columns := make([]alphameticColumn, maxLen)
	for pos := 0; pos < maxLen; pos++ {
		counts := make([]int, len(letters))
		for _, word := range addends {
			if i := len(word) - 1 - pos; i >= 0 {
				counts[word[i]]++
			}
		}
		resultLetter := -1
		if pos < len(result) {
			resultLetter = result[len(result)-1-pos]
		}
		columns[pos] = alphameticColumn{counts: counts, result: resultLetter}
	}

	// The carry out of a column is bounded by the number of addends. This
	// recurrence keeps the per-position bound as tight as possible.
	maxCarryIn := make([]int, maxLen)
	for pos := 1; pos < maxLen; pos++ {
		addendsBelow := 0
		for _, count := range columns[pos-1].counts {
			addendsBelow += count
		}
		maxCarryIn[pos] = (9*addendsBelow + maxCarryIn[pos-1]) / 10
	}

	s := &alphameticSolver{
		columns:    columns,
		digits:     make([]int, len(letters)),
		leading:    leading,
		maxCarryIn: maxCarryIn,
	}
	for i := range s.digits {
		s.digits[i] = -1
	}

	if !s.search(0, 0) {
		return nil, errors.New("no solution")
	}

	solution := make(map[string]int, len(letters))
	for i, letter := range letters {
		solution[string(letter)] = s.digits[i]
	}
	return solution, nil
}

func parseAlphametic(puzzle string) ([][]int, []int, []rune, []bool, map[rune]int, error) {
	normalized := strings.Map(func(r rune) rune {
		if unicode.IsSpace(r) {
			return -1
		}
		return unicode.ToUpper(r)
	}, puzzle)

	parts := strings.Split(normalized, "==")
	if len(parts) != 2 || parts[0] == "" || parts[1] == "" {
		return nil, nil, nil, nil, nil, errors.New("invalid puzzle")
	}

	letters := make([]rune, 0, 10)
	index := make(map[rune]int)

	parseWord := func(text string) ([]int, error) {
		if text == "" {
			return nil, errors.New("invalid puzzle")
		}
		runes := []rune(text)
		word := make([]int, len(runes))
		for i, r := range runes {
			if r < 'A' || r > 'Z' {
				return nil, errors.New("invalid puzzle")
			}
			idx, ok := index[r]
			if !ok {
				idx = len(letters)
				index[r] = idx
				letters = append(letters, r)
			}
			word[i] = idx
		}
		return word, nil
	}

	var addends [][]int
	for _, text := range strings.Split(parts[0], "+") {
		word, err := parseWord(text)
		if err != nil {
			return nil, nil, nil, nil, nil, err
		}
		addends = append(addends, word)
	}

	result, err := parseWord(parts[1])
	if err != nil {
		return nil, nil, nil, nil, nil, err
	}

	leading := make([]bool, len(letters))
	for _, word := range addends {
		if len(word) > 1 {
			leading[word[0]] = true
		}
	}
	if len(result) > 1 {
		leading[result[0]] = true
	}

	return addends, result, letters, leading, index, nil
}

// search solves columns from least significant to most significant. carryIn
// is the carry produced by the previous column.
func (s *alphameticSolver) search(pos, carryIn int) bool {
	if pos == len(s.columns) {
		return carryIn == 0 && s.fillRemaining()
	}

	column := s.columns[pos]
	base := carryIn
	if column.result >= 0 && s.digits[column.result] >= 0 {
		base -= s.digits[column.result]
	}

	terms := make([]alphameticTerm, 0, len(column.counts)+1)
	for letter, count := range column.counts {
		if count == 0 {
			continue
		}
		if s.digits[letter] >= 0 {
			base += count * s.digits[letter]
		} else {
			terms = append(terms, alphameticTerm{letter: letter, coeff: count})
		}
	}
	if column.result >= 0 && s.digits[column.result] < 0 {
		found := false
		for i := range terms {
			if terms[i].letter == column.result {
				terms[i].coeff--
				found = true
				break
			}
		}
		if !found {
			terms = append(terms, alphameticTerm{letter: column.result, coeff: -1})
		}
	}

	sort.Slice(terms, func(i, j int) bool {
		a, b := terms[i].coeff, terms[j].coeff
		if a < 0 {
			a = -a
		}
		if b < 0 {
			b = -b
		}
		return a > b
	})

	maxCarryOut := 0
	if pos+1 < len(s.columns) {
		maxCarryOut = s.maxCarryIn[pos+1]
	}

	return s.assignColumn(pos, terms, base, maxCarryOut)
}

func (s *alphameticSolver) assignColumn(pos int, terms []alphameticTerm, base, maxCarryOut int) bool {
	cache := make(map[uint64]alphameticDPResult)

	var compute func(i, mask int) alphameticDPResult
	compute = func(i, mask int) alphameticDPResult {
		if i == len(terms) {
			return alphameticDPResult{residues: 1, min: 0, max: 0}
		}

		key := uint64(i)<<10 | uint64(mask)
		if cached, ok := cache[key]; ok {
			return cached
		}

		result := alphameticDPResult{min: 1 << 30, max: -1 << 30}
		term := terms[i]
		for digit := 0; digit <= 9; digit++ {
			if mask&(1<<uint(digit)) != 0 || (digit == 0 && s.leading[term.letter]) {
				continue
			}
			child := compute(i+1, mask|1<<uint(digit))
			if child.residues == 0 {
				continue
			}
			contribution := term.coeff * digit
			result.residues |= shiftResidues(child.residues, contribution)
			if contribution+child.min < result.min {
				result.min = contribution + child.min
			}
			if contribution+child.max > result.max {
				result.max = contribution + child.max
			}
		}
		cache[key] = result
		return result
	}

	initialMask := 0
	for digit, used := range s.used {
		if used {
			initialMask |= 1 << uint(digit)
		}
	}

	var recurse func(i, mask, sum int) bool
	recurse = func(i, mask, sum int) bool {
		if i == len(terms) {
			total := base + sum
			if total < 0 || total > 10*maxCarryOut || total%10 != 0 {
				return false
			}
			return s.search(pos+1, total/10)
		}

		neededResidue := ((10-(base+sum)%10)%10 + 10) % 10
		remaining := compute(i, mask)
		if remaining.residues&(1<<uint(neededResidue)) == 0 {
			return false
		}
		if base+sum+remaining.min > 10*maxCarryOut || base+sum+remaining.max < 0 {
			return false
		}

		term := terms[i]
		for digit := 0; digit <= 9; digit++ {
			bit := 1 << uint(digit)
			if mask&bit != 0 || (digit == 0 && s.leading[term.letter]) {
				continue
			}
			contribution := term.coeff * digit
			nextNeeded := (neededResidue - contribution%10 + 10) % 10
			nextMask := mask | bit
			if compute(i+1, nextMask).residues&(1<<uint(nextNeeded)) == 0 {
				continue
			}

			s.used[digit] = true
			s.digits[term.letter] = digit
			if recurse(i+1, nextMask, sum+contribution) {
				return true
			}
			s.digits[term.letter] = -1
			s.used[digit] = false
		}
		return false
	}

	return recurse(0, initialMask, 0)
}

func shiftResidues(bits uint16, amount int) uint16 {
	amount %= 10
	if amount < 0 {
		amount += 10
	}
	var shifted uint16
	for residue := 0; residue < 10; residue++ {
		if bits&(1<<uint(residue)) != 0 {
			shifted |= 1 << uint((residue+amount)%10)
		}
	}
	return shifted
}

func (s *alphameticSolver) fillRemaining() bool {
	changed := make([]int, 0, len(s.digits))
	assign := func(letter, digit int) {
		s.digits[letter] = digit
		s.used[digit] = true
		changed = append(changed, letter)
	}
	fail := func() bool {
		for _, letter := range changed {
			s.used[s.digits[letter]] = false
			s.digits[letter] = -1
		}
		return false
	}

	for letter, digit := range s.digits {
		if digit != -1 || !s.leading[letter] {
			continue
		}
		found := false
		for d := 1; d <= 9; d++ {
			if !s.used[d] {
				assign(letter, d)
				found = true
				break
			}
		}
		if !found {
			return fail()
		}
	}

	for letter, digit := range s.digits {
		if digit != -1 {
			continue
		}
		found := false
		for d := 0; d <= 9; d++ {
			if !s.used[d] {
				assign(letter, d)
				found = true
				break
			}
		}
		if !found {
			return fail()
		}
	}
	return true
}
