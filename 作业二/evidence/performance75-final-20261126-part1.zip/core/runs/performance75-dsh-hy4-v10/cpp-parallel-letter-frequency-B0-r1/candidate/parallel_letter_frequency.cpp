#include "parallel_letter_frequency.h"

#include <algorithm>
#include <array>
#include <cstddef>
#include <thread>

namespace parallel_letter_frequency {
namespace {

using Counts = std::array<int, 26>;

void count_letters(const std::vector<std::string_view>& texts,
                   std::size_t begin,
                   std::size_t end,
                   Counts& counts) {
    for (std::size_t i = begin; i < end; ++i) {
        for (const char ch : texts[i]) {
            if (ch >= 'a' && ch <= 'z') {
                ++counts[static_cast<std::size_t>(ch - 'a')];
            } else if (ch >= 'A' && ch <= 'Z') {
                ++counts[static_cast<std::size_t>(ch - 'A')];
            }
        }
    }
}

}  // namespace

std::map<char, int> frequency(const std::vector<std::string_view>& texts) {
    std::map<char, int> result;
    if (texts.empty()) {
        return result;
    }

    const unsigned int available_threads = std::thread::hardware_concurrency();
    const std::size_t thread_count =
        available_threads == 0
            ? 1
            : std::min(static_cast<std::size_t>(available_threads), texts.size());

    std::vector<Counts> partial_counts(thread_count);
    std::vector<std::thread> threads;
    threads.reserve(thread_count > 1 ? thread_count - 1 : 0);

    if (thread_count == 1) {
        count_letters(texts, 0, texts.size(), partial_counts[0]);
    } else {
        const std::size_t chunk_size =
            (texts.size() + thread_count - 1) / thread_count;

        for (std::size_t thread_index = 1; thread_index < thread_count;
             ++thread_index) {
            const std::size_t begin = thread_index * chunk_size;
            if (begin >= texts.size()) {
                break;
            }
            const std::size_t end = std::min(begin + chunk_size, texts.size());
            threads.emplace_back([&texts, &partial_counts, begin, end,
                                  thread_index] {
                count_letters(texts, begin, end, partial_counts[thread_index]);
            });
        }

        count_letters(texts, 0, std::min(chunk_size, texts.size()),
                      partial_counts[0]);

        for (auto& thread : threads) {
            thread.join();
        }
    }

    for (const Counts& counts : partial_counts) {
        for (std::size_t letter = 0; letter < counts.size(); ++letter) {
            if (counts[letter] != 0) {
                result[static_cast<char>('a' + letter)] += counts[letter];
            }
        }
    }

    return result;
}

}  // namespace parallel_letter_frequency
