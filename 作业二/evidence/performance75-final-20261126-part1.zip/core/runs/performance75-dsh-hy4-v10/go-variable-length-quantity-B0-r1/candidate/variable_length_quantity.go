package variablelengthquantity

import "fmt"

func EncodeVarint(input []uint32) []byte {
	output := make([]byte, 0, len(input))

	for _, value := range input {
		var groups [5]byte
		i := len(groups)

		for {
			i--
			groups[i] = byte(value & 0x7f)
			value >>= 7

			if value == 0 {
				break
			}
		}

		for j := i; j < len(groups)-1; j++ {
			groups[j] |= 0x80
		}

		output = append(output, groups[i:]...)
	}

	return output
}

func DecodeVarint(input []byte) ([]uint32, error) {
	output := make([]uint32, 0, len(input))

	var value uint64
	var count int

	for _, b := range input {
		if count == 5 {
			return nil, fmt.Errorf("invalid VLQ sequence: value exceeds 32 bits")
		}

		value = (value << 7) | uint64(b&0x7f)
		count++

		if b&0x80 == 0 {
			if value > uint64(^uint32(0)) {
				return nil, fmt.Errorf("invalid VLQ sequence: value exceeds 32 bits")
			}

			output = append(output, uint32(value))
			value = 0
			count = 0
		}
	}

	if count != 0 {
		return nil, fmt.Errorf("invalid VLQ sequence: incomplete sequence")
	}

	return output, nil
}
