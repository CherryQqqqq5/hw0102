export class Triangle {
  constructor(...sides) {
    this.sides = sides;
  }

  get isValid() {
    const [a, b, c] = this.sides;

    return (
      this.sides.length === 3 &&
      this.sides.every((side) => typeof side === 'number' && Number.isFinite(side) && side > 0) &&
      a + b >= c &&
      b + c >= a &&
      a + c >= b
    );
  }

  get isEquilateral() {
    const [a, b, c] = this.sides;
    return this.isValid && a === b && b === c;
  }

  get isIsosceles() {
    const [a, b, c] = this.sides;
    return this.isValid && (a === b || b === c || a === c);
  }

  get isScalene() {
    const [a, b, c] = this.sides;
    return this.isValid && a !== b && b !== c && a !== c;
  }
}
