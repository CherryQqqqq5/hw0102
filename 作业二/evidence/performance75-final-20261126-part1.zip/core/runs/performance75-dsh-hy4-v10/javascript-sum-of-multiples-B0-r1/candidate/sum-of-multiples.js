export const sum = (factors, limit) => {
  const multiples = new Set();

  for (const factor of factors) {
    if (factor <= 0) {
      continue;
    }

    for (let multiple = factor; multiple < limit; multiple += factor) {
      multiples.add(multiple);
    }
  }

  return Array.from(multiples).reduce((total, multiple) => total + multiple, 0);
};
