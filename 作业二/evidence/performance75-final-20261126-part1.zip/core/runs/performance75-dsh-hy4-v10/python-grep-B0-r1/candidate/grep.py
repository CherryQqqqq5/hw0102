def _parse_flags(flags):
    if not flags:
        return set()

    if isinstance(flags, str):
        tokens = flags.replace(",", " ").split()
        parsed = set()
        for token in tokens:
            if token.startswith("--"):
                continue
            if token.startswith("-") and len(token) > 2:
                parsed.update("-" + char for char in token[1:])
            elif token.startswith("-"):
                parsed.add(token)
            else:
                parsed.add("-" + token)
        return parsed

    return set(flags)


def grep(pattern, flags, files):
    flags = _parse_flags(flags)
    ignore_case = "-i" in flags
    line_numbers = "-n" in flags and "-l" not in flags
    filenames_only = "-l" in flags
    invert = "-v" in flags
    whole_line = "-x" in flags
    multiple_files = len(files) > 1

    search_for = pattern.casefold() if ignore_case else pattern
    output = []

    for filename in files:
        with open(filename) as file:
            file_has_match = False
            for line_number, line in enumerate(file, start=1):
                content = line.rstrip("\r\n")
                comparable = content.casefold() if ignore_case else content
                matches = comparable == search_for if whole_line else search_for in comparable
                selected = not matches if invert else matches

                if not selected:
                    continue

                if filenames_only:
                    output.append(filename + "\n")
                    break

                parts = []
                if multiple_files:
                    parts.append(filename)
                if line_numbers:
                    parts.append(str(line_number))
                parts.append(content)
                output.append(":".join(parts) + "\n")

    return "".join(output)
