class PhoneNumber {

    private final String number;

    PhoneNumber(String numberString) {
        for (int i = 0; i < numberString.length(); i++) {
            char current = numberString.charAt(i);
            if (Character.isLetter(current)) {
                throw new IllegalArgumentException("letters not permitted");
            }
            if (!Character.isDigit(current)
                    && !Character.isWhitespace(current)
                    && current != '+'
                    && current != '-'
                    && current != '('
                    && current != ')'
                    && current != '.') {
                throw new IllegalArgumentException("punctuations not permitted");
            }
        }

        StringBuilder digits = new StringBuilder();
        for (int i = 0; i < numberString.length(); i++) {
            char current = numberString.charAt(i);
            if (Character.isDigit(current)) {
                digits.append(current);
            }
        }

        if (digits.length() < 10) {
            throw new IllegalArgumentException("must not be fewer than 10 digits");
        }
        if (digits.length() > 11) {
            throw new IllegalArgumentException("must not be greater than 11 digits");
        }

        String cleaned = digits.toString();
        if (cleaned.length() == 11) {
            if (cleaned.charAt(0) != '1') {
                throw new IllegalArgumentException("11 digits must start with 1");
            }
            cleaned = cleaned.substring(1);
        }

        if (cleaned.charAt(0) == '0') {
            throw new IllegalArgumentException("area code cannot start with zero");
        }
        if (cleaned.charAt(0) == '1') {
            throw new IllegalArgumentException("area code cannot start with one");
        }
        if (cleaned.charAt(3) == '0') {
            throw new IllegalArgumentException("exchange code cannot start with zero");
        }
        if (cleaned.charAt(3) == '1') {
            throw new IllegalArgumentException("exchange code cannot start with one");
        }

        this.number = cleaned;
    }

    String getNumber() {
        return number;
    }

}
