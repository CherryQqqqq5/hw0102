def proverb(*pieces, qualifier=None):
    lines = [
        f"For want of a {first} the {second} was lost."
        for first, second in zip(pieces, pieces[1:])
    ]

    if pieces:
        original = f"{qualifier} {pieces[0]}" if qualifier else pieces[0]
        lines.append(f"And all for the want of a {original}.")

    return lines
