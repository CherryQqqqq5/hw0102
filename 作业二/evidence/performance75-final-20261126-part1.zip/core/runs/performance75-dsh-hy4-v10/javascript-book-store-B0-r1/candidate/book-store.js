const BOOK_PRICE_IN_CENTS = 800;

const GROUP_PRICES_IN_CENTS = [
  0,
  BOOK_PRICE_IN_CENTS,
  Math.round(2 * BOOK_PRICE_IN_CENTS * 0.95),
  Math.round(3 * BOOK_PRICE_IN_CENTS * 0.9),
  Math.round(4 * BOOK_PRICE_IN_CENTS * 0.8),
  Math.round(5 * BOOK_PRICE_IN_CENTS * 0.75),
];

const countBits = (mask) => {
  let count = 0;
  while (mask > 0) {
    count += mask & 1;
    mask >>= 1;
  }
  return count;
};

export const cost = (books) => {
  const counts = [0, 0, 0, 0, 0];
  for (const book of books) {
    counts[book - 1] += 1;
  }

  const prices = new Map();

  const minimumCost = (remaining) => {
    remaining.sort((a, b) => b - a);

    const key = remaining.join(',');
    if (prices.has(key)) {
      return prices.get(key);
    }

    if (remaining[0] === 0) {
      return 0;
    }

    let best = Infinity;

    for (let mask = 1; mask < 32; mask += 1) {
      const groupSize = countBits(mask);
      const next = remaining.slice();
      let possible = true;

      for (let book = 0; book < 5; book += 1) {
        if (mask & (1 << book)) {
          if (next[book] === 0) {
            possible = false;
            break;
          }
          next[book] -= 1;
        }
      }

      if (possible) {
        const total = GROUP_PRICES_IN_CENTS[groupSize] + minimumCost(next);
        if (total < best) {
          best = total;
        }
      }
    }

    prices.set(key, best);
    return best;
  };

  return minimumCost(counts);
};
