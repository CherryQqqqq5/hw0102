#include "all_your_base.h"

#include <vector>

namespace all_your_base {

std::vector<unsigned int> convert(unsigned int input_base,
                                  const std::vector<unsigned int>& input_digits,
                                  unsigned int output_base) {
    if (input_base < 2 || output_base < 2) {
        throw std::invalid_argument("bases must be at least 2");
    }

    std::vector<unsigned int> digits;
    bool found_nonzero = false;
    for (unsigned int digit : input_digits) {
        if (digit >= input_base) {
            throw std::invalid_argument("digit out of range for input base");
        }
        if (found_nonzero || digit != 0) {
            found_nonzero = true;
            digits.push_back(digit);
        }
    }

    if (!found_nonzero) {
        return {};
    }

    std::vector<unsigned int> result;
    while (!digits.empty()) {
        unsigned long long remainder = 0;
        std::vector<unsigned int> quotient;
        quotient.reserve(digits.size());

        for (unsigned int digit : digits) {
            const unsigned long long value = remainder * input_base + digit;
            const unsigned int quotient_digit =
                static_cast<unsigned int>(value / output_base);
            remainder = value % output_base;

            if (!quotient.empty() || quotient_digit != 0) {
                quotient.push_back(quotient_digit);
            }
        }

        result.push_back(static_cast<unsigned int>(remainder));
        digits.swap(quotient);
    }

    return std::vector<unsigned int>(result.rbegin(), result.rend());
}

}  // namespace all_your_base
