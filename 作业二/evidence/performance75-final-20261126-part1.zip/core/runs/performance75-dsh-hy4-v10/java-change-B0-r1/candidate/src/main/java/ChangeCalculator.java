import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class ChangeCalculator {
    private final List<Integer> currencyCoins;

    ChangeCalculator(List<Integer> currencyCoins) {
        this.currencyCoins = new ArrayList<>();
        for (Integer coin : currencyCoins) {
            if (coin != null && coin > 0 && !this.currencyCoins.contains(coin)) {
                this.currencyCoins.add(coin);
            }
        }
        this.currencyCoins.sort(Integer::compareTo);
    }

    List<Integer> computeMostEfficientChange(int grandTotal) {
        if (grandTotal < 0) {
            throw new IllegalArgumentException("Negative totals are not allowed.");
        }
        if (grandTotal == 0) {
            return new ArrayList<>();
        }

        int unreachable = grandTotal + 1;
        int[] minimumCoins = new int[grandTotal + 1];
        int[] chosenCoin = new int[grandTotal + 1];
        Arrays.fill(minimumCoins, unreachable);
        Arrays.fill(chosenCoin, -1);
        minimumCoins[0] = 0;

        for (int amount = 1; amount <= grandTotal; amount++) {
            for (int coin : currencyCoins) {
                if (coin > amount) {
                    break;
                }
                int previousAmount = amount - coin;
                if (minimumCoins[previousAmount] != unreachable
                        && minimumCoins[previousAmount] + 1 < minimumCoins[amount]) {
                    minimumCoins[amount] = minimumCoins[previousAmount] + 1;
                    chosenCoin[amount] = coin;
                }
            }
        }

        if (minimumCoins[grandTotal] == unreachable) {
            throw new IllegalArgumentException(
                    "The total " + grandTotal + " cannot be represented in the given currency.");
        }

        int[] counts = new int[currencyCoins.size()];
        int remaining = grandTotal;
        while (remaining > 0) {
            int coin = chosenCoin[remaining];
            counts[currencyCoins.indexOf(coin)]++;
            remaining -= coin;
        }

        List<Integer> change = new ArrayList<>();
        for (int i = 0; i < currencyCoins.size(); i++) {
            for (int j = 0; j < counts[i]; j++) {
                change.add(currencyCoins.get(i));
            }
        }
        return change;
    }
}
