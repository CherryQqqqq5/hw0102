package trinary

import (
	"errors"
	"math"
)

func ParseTrinary(arg string) (int64, error) {
	if len(arg) == 0 {
		return 0, errors.New("invalid trinary number")
	}

	const maxDigit = int64(2)
	cutoff := int64(math.MaxInt64) / 3
	cutoffDigit := int64(math.MaxInt64) % 3

	var value int64
	for i := 0; i < len(arg); i++ {
		digit := int64(arg[i] - '0')
		if digit < 0 || digit > maxDigit {
			return 0, errors.New("invalid trinary number")
		}
		if value > cutoff || (value == cutoff && digit > cutoffDigit) {
			return 0, errors.New("trinary number overflows int64")
		}
		value = value*3 + digit
	}

	return value, nil
}
