#include "allergies.h"

#include <utility>
#include <vector>

namespace allergies {
namespace {

constexpr unsigned kKnownAllergensMask = 255;

const std::vector<std::pair<std::string, unsigned>>& allergens() {
    static const std::vector<std::pair<std::string, unsigned>> known_allergens = {
        {"eggs", 1},
        {"peanuts", 2},
        {"shellfish", 4},
        {"strawberries", 8},
        {"tomatoes", 16},
        {"chocolate", 32},
        {"pollen", 64},
        {"cats", 128},
    };
    return known_allergens;
}

}  // namespace

allergy_test::allergy_test(unsigned score) : score_(score & kKnownAllergensMask) {}

bool allergy_test::is_allergic_to(const std::string& allergen) const {
    for (const auto& candidate : allergens()) {
        if (candidate.first == allergen) {
            return (score_ & candidate.second) != 0;
        }
    }
    return false;
}

std::unordered_set<std::string> allergy_test::get_allergies() const {
    std::unordered_set<std::string> result;

    for (const auto& candidate : allergens()) {
        if ((score_ & candidate.second) != 0) {
            result.emplace(candidate.first);
        }
    }

    return result;
}

}  // namespace allergies
