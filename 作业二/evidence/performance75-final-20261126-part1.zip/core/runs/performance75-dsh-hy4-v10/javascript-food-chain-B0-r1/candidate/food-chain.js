const CREATURES = [
  { name: 'fly', remark: '', modifier: '' },
  {
    name: 'spider',
    remark: 'It wriggled and jiggled and tickled inside her.',
    modifier: ' that wriggled and jiggled and tickled inside her',
  },
  { name: 'bird', remark: 'How absurd to swallow a bird!', modifier: '' },
  { name: 'cat', remark: 'Imagine that, to swallow a cat!', modifier: '' },
  { name: 'dog', remark: 'What a hog, to swallow a dog!', modifier: '' },
  {
    name: 'goat',
    remark: 'Just opened her throat and swallowed a goat!',
    modifier: '',
  },
  {
    name: 'cow',
    remark: "I don't know how she swallowed a cow!",
    modifier: '',
  },
  { name: 'horse', remark: "She's dead, of course!", modifier: '' },
];

export class Song {
  verse(number) {
    const index = number - 1;
    const creature = CREATURES[index];
    const lines = [`I know an old lady who swallowed a ${creature.name}.`];

    if (creature.remark) {
      lines.push(creature.remark);
    }

    if (creature.name === 'horse') {
      return `${lines.join('\n')}\n`;
    }

    for (let current = index; current > 0; current -= 1) {
      const caught = CREATURES[current - 1];
      lines.push(
        `She swallowed the ${CREATURES[current].name} to catch the ` +
          `${caught.name}${caught.modifier}.`,
      );
    }

    lines.push("I don't know why she swallowed the fly. Perhaps she'll die.");

    return `${lines.join('\n')}\n`;
  }

  verses(first, last) {
    const verses = [];

    for (let number = first; number <= last; number += 1) {
      verses.push(this.verse(number));
    }

    return `${verses.join('\n')}\n`;
  }
}
